import os
import hashlib
import re
from datetime import datetime
from faker import Faker 
import matplotlib.pyplot as plt
import numpy as np
import qrcode as qr # pip install qrcode for generating QR codes

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def generate_card_data():
    fake = Faker() 

    card_number = fake.credit_card_number(card_type=None)  # Generates a random credit card number
    expiry_date = fake.credit_card_expire(start="now", end="+10y", date_format="%m/%y") # Generates a random expiry date
    cvv = fake.credit_card_security_code(card_type=None) # Generates a random CVV code

    return (card_number, expiry_date, cvv) # Returns the generated card data in a tuple

def hash_password(password):
    encoded_password = password.encode() # first encode the password to switch it from string to bytes. Because, hashing works on bytes.

    sha256 = hashlib.new("SHA256") # Creating new hashing key
    sha256.update(encoded_password)
    hashed_password = sha256.hexdigest()  
    return hashed_password

def validate_personal_number(personal_number):
    if not re.match(r"^\d{8}-\d{4}$", personal_number):
        return False  

    date_part = personal_number[:8]
    year = int(date_part[:4])
    month = int(date_part[4:6])
    day = int(date_part[6:8])

    try:
        datetime(year, month, day)  
    except ValueError:
        return False

    return True

def check_password_user(personnumber, try_password):
    from data_handler import load_data
    users_json = load_data()
    hashed_try = hash_password(try_password)
    
    if hashed_try == users_json["users"][personnumber]["password"]:
        return True
    else:
        return False

# I feel like the name is not really representative
def calculate():
    try:
        capital = int(input("Please insert the amount of capital you would like to invest: "))
        if capital <= 0:
            raise ValueError("Capital must be a positive integer.")
        
        interest = float(input("Please insert the interest rate (in decimals, e.g., 0.05 for 5%): "))
        if interest <= 0 or interest >= 1:
            raise ValueError("Interest rate must be a decimal between 0 and 1.")
        
        years = int(input("Insert the time period (in years): "))
        if years <= 0:
            raise ValueError("Years must be a positive integer.")


        compound = int(input("Is your interest compound or simple?\n1. Compound\n2. Simple\n"))
        if compound not in [1, 2]:
            raise ValueError("Please select either 1 (Compound) or 2 (Simple).")
            
        if compound == 1:
                print("""
        Please select the interest frequency:
        1. Yearly
        2. Monthly
        3. Quarterly (every 3 months)
        4. Triannually (every 4 months)
        5. Semiannually (every 6 months)
        6. Other""")
            
                frequency = int(input("Enter the number corresponding to your choice: "))
            
                if frequency == 1:
                    periods_per_year = 1
                elif frequency == 2:
                    periods_per_year = 12
                elif frequency == 3:
                    periods_per_year = 4
                elif frequency == 4:
                    periods_per_year = 3
                elif frequency == 5:
                    periods_per_year = 2
                elif frequency == 6:
                    try:
                        custom_frequency = (input("Enter your interest frequency (in months per year): "))
                        
                        if float(custom_frequency).is_integer():
                            custom_frequency = int(custom_frequency)
                            if custom_frequency <= 0 or custom_frequency > 12 or 12 % custom_frequency != 0:
                                raise ValueError("Custom frequency must evenly divide 12 and be between 1 and 12.")
                            
                            periods_per_year = 12 // custom_frequency    

                        else:
                            raise ValueError
                    
                    except ValueError:
                        print("Invalid frequency choice.")
                        return
                

                else:
                    print("Invalid choice. Please choose an option [1-6].")
                    return

                finalCapital = capital * (1 + interest/periods_per_year)** (years * periods_per_year)


        elif compound == 2:    
                    
                finalCapital = capital * (1 + years*interest)

        else:
            print("Invalid choice.")
            return
        

        print(f"In {years} years, you would have a final capital of ${finalCapital:.2f}, having a profit of ${(finalCapital - capital):.2f}.")
        interest_plot(years, finalCapital)
        
        return finalCapital # Camel case in python?
    
    except ValueError as e:
        print(f"Error: {e}")
        return

def interest_plot(years, final_capital):
    # make the years into a list: 5
    years_list = []
    year = 2024
    final_capital_list =[]

    for i in range (years):
        years_list.append(year)
        year += 2

        final_capital_list.append(final_capital)
        final_capital += 10
    
    x_axis_data = years_list
    y_axis_data = final_capital_list

    x_axis = np.array(x_axis_data)
    y_axis = np.array(y_axis_data)

    plt.plot(x_axis, y_axis, label = "graph")
    plt.show()

def generate_qr_code():
    google_form_url = "https://docs.google.com/forms/d/e/1FAIpQLSczr8VGL9aEPxqUOtdGfuzvvwIpHN7OksqSuVg9UFGj1bCP_A/viewform?usp=sharing"
    qr_code = qr.QRCode(version=1, error_correction=qr.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr_code.add_data(google_form_url)
    qr_code.make(fit=True)
    img = qr_code.make_image(fill_color="black", back_color="white")
    img.show()