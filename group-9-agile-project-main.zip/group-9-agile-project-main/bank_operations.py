import time
import tkinter   # pip install tkinter, so that we can generate a gui to show cards.
from tkinter import *
from PIL import Image, ImageTk # pip install pillow, to handle the image files.
from data_handler import load_data, save_data, generate_account_number
from menus import childs_menu
from utils import clear_console, validate_personal_number
from datetime import datetime, timedelta
import requests
import json
import matplotlib.pyplot as plt

def show_balance(id):
    data = load_data()
    balance = data["users"][id]["balance"]
    print("Your balance is: ", balance)
    input("Press any key to return")



def create_savings_account(personal_number, interest): # we can define different interests for different savings accounts
    data = load_data()
    users = data["users"]

    if personal_number not in users:
        return print("Error: account not found.")
    
    savings_account_number = generate_account_number()
    
    user = users[personal_number]
    balance = user["balance"]
    savings_balance = -1
    
    while savings_balance > balance or savings_balance < 0:
        clear_console()
        savings_balance = float(input(f"Enter initial deposit for savings account (availabe amout is: {balance}): "))
        if savings_balance > balance or savings_balance < 0:
            clear_console()
            print("Error: Insufficient funds.")
            time.sleep(1)
        else:
            balance -= savings_balance
            user["balance"] = balance
            user["savings_account"] = {"account number": savings_account_number, "balance": savings_balance, "interest": interest}
            
    save_data(data)
    print(f"Savings account created successfully! Account Number: {savings_account_number}")
    time.sleep(2)
    

def show_childs_balance(child_id):
    data = load_data()
    for user, info in data.items():
        if "child_accounts" in info:
            child_accounts = info["child_accounts"]
            if child_id in child_accounts: 
                balance = child_accounts[child_id]["balance"]
    print("Your balance is: ", balance)
    input("Press any key to return")


def create_child_account(parent_person_number):
    data = load_data()
    users = data["users"]

    
    if parent_person_number not in users:
        print("Error: Parent's account not found.")
        return

    parent = users[parent_person_number]

    
    if "child_accounts" not in parent:
        parent["child_accounts"] = {}

    
    childs_account_number = generate_account_number()
    child_name = input("Insert your child's full name: ")
    child_personal_number = input("Insert your child's personal number: ")
    child_password = input("Input child password: ")

    
    if not validate_personal_number(child_personal_number):
        print("Error: Invalid personal number.")
        return


    parent["child_accounts"][child_personal_number] = {
        "permissions": {
            "login permission": True,
            "withdraw permission": True,
            "transactions permission": True,
            "deposit permission": True
        },
        "child account number": childs_account_number,
        "balance": 0,
        "full name": child_name,
        "child personal number": child_personal_number,
        "child's password": child_password,
        "transaction_history": []
    }

    save_data(data)
    print(f"Your child's account was created successfully! Account Number: {childs_account_number}")


def manage_child_account(parent_person_number):
    data = load_data()
    if "child_accounts" in data["users"][parent_person_number]:
        print("Your children: ")
        for i in data["users"][parent_person_number]["child_accounts"]:
            print(i)
        child_choice = input("Enter chosen persnal number:")
        if child_choice in data["users"][parent_person_number]["child_accounts"]:
            clear_console()
            child_menu = """
1. Child info
2. Change child Permissions
3. Exit"""
            print(child_menu)
            child_menu = int(input("Enter:"))
            if child_menu ==  1:
                print(data["users"][parent_person_number]["child_accounts"][child_choice])
                back = input("enter any key to return")
            elif child_menu == 2:
                change_child_permissions(parent_person_number, child_choice)
            elif child_menu == 3:
                return
            else:
                print("Error: Invalid input. Please chose from the given options.")
                manage_child_account(parent_person_number)
            
                

def change_child_permissions(parent_person_number, child_personal_number):
    data = load_data()
    menu_choice = 1
    for i in data["users"][parent_person_number]["child_accounts"][child_personal_number]["permissions"]:
                    
        print(str(menu_choice) + "." + i)
        menu_choice += 1
    print ("5. Exit")
    permissions_choice = int(input("enter:"))

    if 0 < permissions_choice < 5:
        choice = 0
        for i in data["users"][parent_person_number]["child_accounts"][child_personal_number]["permissions"]:
            choice += 1
            if permissions_choice == choice:
                permission = print(f"""
{i} allowed?:
1. True
2. False""")
                permission = int(input("enter: "))
                if permission == 1:
                    data["users"][parent_person_number]["child_accounts"][child_personal_number]["permissions"][i] = True
                    print("Permission changed sucessfully")
                    time.sleep(2)
                elif permission == 2:
                    data["users"][parent_person_number]["child_accounts"][child_personal_number]["permissions"][i] = False
                    print("Permission changed sucessfully")
                    time.sleep(2)
                else:
                    print("Error: Invalid input. Please chose from the given options ")
                    change_child_permissions(parent_person_number, child_personal_number)
    elif permissions_choice == 5:
        return

    else:
        print("Error: Invalid input. Please chose from the given options ")
        change_child_permissions(parent_person_number, child_personal_number)

    save_data(data)


def withdraw_money(personal_number):
    data = load_data()
    user = data["users"][personal_number]
    withdrawl = float(input("Enter amount to withdraw: ").strip())
    
    if withdrawl <= user["balance"]:
        user["balance"] -= withdrawl
        save_data(data)
        transaction_date = datetime.now().strftime("%Y-%m-%d")
        user["transaction_history"].append({
            "type": "withdrawal",
            "amount": withdrawl,
            "date": transaction_date,
            "new_balance": user["balance"]
        })
        save_data(data)
        print("Withdrawal successful.")
        print(f"{withdrawl} SEK has been withdrawn. Your new balance is {user['balance']} SEK.")
    else:
        print("Insufficient funds.")
    
    time.sleep(2)
    clear_console()


def child_withdraw_money(child_personal_number, name):
    data = load_data()

    child_exist = 0

    

    for i in data["users"]:
        if "child_accounts" in data["users"][i]:
                child_accounts = data["users"][i]["child_accounts"]
                if child_personal_number in child_accounts: 
                    if data["users"][i]["child_accounts"][child_personal_number]["permissions"]["withdraw permission"] == True:

                        child = data["users"][i]["child_accounts"][child_personal_number]


                        try:
                            withdrawl = float(input("Enter amount to withdraw: ").strip())
                        except ValueError:
                            print("Please enter numbers only.")
                            time.sleep(2)
                            clear_console()
                            childs_menu(child_personal_number, name)
    
                        if withdrawl <= child["balance"]:
                            child["balance"] -= withdrawl
                            save_data(data)
                            transaction_date = datetime.now().strftime("%Y-%m-%d")
                            child["transaction_history"].append({
                            "type": "withdrawal",
                            "amount": withdrawl,
                            "date": transaction_date,
                            "new_balance": child["balance"]})

                            save_data(data)

                            print("Withdrawal successful.")
                            print(f"{withdrawl} SEK has been withdrawn. Your new balance is {child['balance']} SEK.")
                            time.sleep(2)
                        else:
                            print("Insufficient funds.")
                            time.sleep(2)
                        child_exist = 1
                        break
                    else:
                        child_exist = 1
                        print("Error: child withdrawl is not allowed")
                        time.sleep(2)

    if child_exist == 0:
        print("Error: could not find parent.")
        time.sleep(2)
    clear_console()
    childs_menu(child_personal_number, name)
    
def deposit_money(personal_number):
    data = load_data()
    user = data["users"].get(personal_number)
    deposit = int(input("How much money would you like to deposit?"))
    
    user["balance"] += deposit
    save_data(data)
    transaction_date = datetime.now().strftime("%Y-%m-%d")
    user["transaction_history"].append({
        "type": "deposit",
        "amount": deposit,
        "date": transaction_date,
        "new_balance": user["balance"]
        })
    save_data(data)
    print(f"{deposit} SEK has been deposited. Your new balance is {user['balance']} SEK.")
    time.sleep(2)
    clear_console()

def transfer_money(personal_number, data):
    sender_data = data["users"][personal_number]
    sender_balance = sender_data["balance"]
    
    try:
        recipient_account_number = int(input("Enter recipient account number: ").strip())
    except ValueError:
        print("Invalid account number. Please enter a numeric value.")
        return
    
    recipient_data = None
    for user_id, user_data in data["users"].items():
        if user_data['account_number'] == recipient_account_number:
            recipient_data = user_data
            break

    if recipient_data:
        try:
            amount = float(input("Enter amount to transfer: ").strip())
        except ValueError:
            print("Invalid amount. Please enter a numeric value.")
            return

        if amount <= sender_balance:

            sender_data["balance"] -= amount
            recipient_data["balance"] += amount

            save_data(data)
            
            transaction_date = datetime.now().strftime("%Y-%m-%d")
            
            sender_data["transaction_history"].append({
                "type": "transfer_sent",
                "amount": amount,
                "recipient": recipient_data["account_number"],
                "date": transaction_date,
                "new_balance": sender_data["balance"]
            })
            
            recipient_data["transaction_history"].append({
                "type": "transfer_received",
                "amount": amount,
                "sender": sender_data["account_number"],
                "date": transaction_date,
                "new_balance": recipient_data["balance"]
            })

            save_data(data)
            
            print("Transfer successful.")
            print(f"New balance: {sender_data['balance']}")
        else:
            print("Insufficient funds.")
    else:
        print("Recipient not found.")

def family_transfer_money(child_id, name):
    data = load_data()


    try:
        recipient_account_number = int(input("Enter recipient account number: ").strip())
    except ValueError:
        print("Invalid account number. Please enter a numeric value.")
        return

        
    for i in data["users"]:
        family_value = 0
        if "child_accounts" in data["users"][i]:
            if child_id in data["users"][i]["child_accounts"]:
                if data["users"][i]["child_accounts"][child_id]["permissions"]["transactions permission"] == True: 
                    sender_balance = data["users"][i]["child_accounts"][child_id]["balance"]
                    recipient_data = data["users"][i]

                    if recipient_account_number == data["users"][i]["account_number"]:
                        family_value = 1
                        recipient_amount = data["users"][i]["balance"]
                        try:
                            amount = float(input("Enter amount to transfer: ").strip())
                        except ValueError:
                            print("Invalid amount. Please enter a numeric value.")
                            time.sleep(2)
                            clear_console()
                            childs_menu(child_id, name)
                        if amount > sender_balance:
                            print("Error: inadequate fundings.")
                            time.sleep(2)
                            clear_console()
                            childs_menu(child_id, name)
                        data["users"][i]["child_accounts"][child_id]["balance"] -= (amount)
                        data["users"][i]["balance"] += (amount)
                        save_data(data)

                        transaction_date = datetime.now().strftime("%Y-%m-%d")
                        data["users"][i]["child_accounts"][child_id]["transaction_history"].append({
                        "type": "transfer_sent",
                        "amount": amount,
                        "recipient": recipient_account_number,
                        "date": transaction_date,
                        "new_balance": data["users"][i]["child_accounts"][child_id]["balance"]})
            
                        recipient_data["transaction_history"].append({
                        "type": "transfer_received",
                        "amount": amount,
                        "sender": data["users"][i]["child_accounts"][child_id]["child account number"],
                        "date": transaction_date,
                        "new_balance": recipient_data["balance"]})

                        print("Transaction sucessful")
                        time.sleep(2)

                        save_data(data)


                        break



                    for child in data["users"][i]["child_accounts"]:
                        if recipient_account_number == data["users"][i]["child_accounts"][child]["child account number"]:
                            family_value = 1
                            recipient_data = data["users"][i]["child_accounts"][child]
                            recipient_amount = data["users"][i]["child_accounts"][child]["balance"]
                            try:
                                amount = float(input("Enter amount to transfer: ").strip())
                            except ValueError:
                                print("Invalid amount. Please enter a numeric value.")
                                time.sleep(2)
                                clear_console()
                                childs_menu(child_id, name)
                            if amount > sender_balance:
                                print("Error: inadequate fundings.")
                                time.sleep(2)
                                clear_console()
                                childs_menu(child_id, name)
                            data["users"][i]["child_accounts"][child_id]["balance"] -= amount
                            data["users"][i]["child_accounts"][child]["balance"] += amount


                            transaction_date = datetime.now().strftime("%Y-%m-%d")
                            data["users"][i]["child_accounts"][child_id]["transaction_history"].append({
                            "type": "transfer_sent",
                            "amount": amount,
                            "recipient": recipient_account_number,
                            "date": transaction_date,
                            "new_balance": data["users"][i]["child_accounts"][child_id]["balance"]})
            
                            recipient_data["transaction_history"].append({
                            "type": "transfer_received",
                            "amount": amount,
                            "sender": data["users"][i]["child_accounts"][child_id]["child account number"],
                            "date": transaction_date,
                            "new_balance": recipient_data["balance"]})

                            print("Transaction sucessful")
                            time.sleep(2)


                            save_data(data)

                    
                        
                            break

                else: 
                    print("Error: Transactions not allowed")
                    time.sleep(2)
                    clear_console()
                    childs_menu(child_id, name)
    if family_value == 0:
        print("Error: Can only send money within family")
        time.sleep(2)
        clear_console()
    childs_menu(child_id, name)
        
def view_user_transaction_history(personal_number):
    data = load_data()
    user = data["users"][personal_number]
    history = user.get("transaction_history", [])
    
    if not history:
        print("No transactions available.")

    else:
        print(f"Transaction History for {user['first_name']} {user['last_name']}:")

        counter = 1 
        for transaction in history:
            print(f"{counter}. Type: {transaction['type'].capitalize()}")
            print(f"   Amount: {transaction['amount']:.2f} SEK")
            print(f"   Date: {transaction['date']}")
            print(f"   Balance after transaction: {transaction['new_balance']:.2f} SEK")
            print("-" * 40)
            counter += 1 
    
    input("Press Enter to return to the previous menu.")
    clear_console()
    
def child_login():
    data = load_data()
    child_id = input("Enter personalnumber (YYYYMMDD-XXXX):")


    for i in data["users"]:
        if ("child_accounts" in data["users"][i]):
            if child_id in data["users"][i]["child_accounts"]:
                if data["users"][i]["child_accounts"][child_id]["permissions"]["login permission"] == True:
                    child_password = input("enter password: ")
                    if child_password == data["users"][i]["child_accounts"][child_id]["child's password"]:
                         childs_menu(child_id, data["users"][i]["child_accounts"][child_id]["full name"])
                    else:
                         print("Error: Wrong password")
                else:
                    print("Child account not allowed login")
                    time.sleep(2)
                    
def show_bank_card(image_path, personal_number):
    data = load_data()
    card_number = data["users"][personal_number]["card_details"][0]
    card_expiration = data["users"][personal_number]["card_details"][1]
    card_cvv = data["users"][personal_number]["card_details"][2]

    card_window = tkinter.Toplevel() # "Toplevel" ensures the card window is displayed on top of the main program window
    card_window.title("Bank Card")
    card_window.geometry("780x480")

    card_canvas = tkinter.Canvas(card_window, width=780, height=480)
    card_canvas.pack(fill="both", expand=True)

    card_image = Image.open(image_path)
    card_image = card_image.resize((800, 500), Image.Resampling.LANCZOS)
    card_photo = ImageTk.PhotoImage(card_image)

    card_canvas.create_image(0, 0, anchor="nw", image=card_photo)
    card_canvas.image = card_photo  # Keep a reference to avoid garbage collection
    card_canvas.create_text(180, 230, text=f"{card_number}", font=("Helvetica", 16, "bold"), fill="white")
    card_canvas.create_text(185, 400, text=f"Expiry date: {card_expiration}", font=("Helvetica", 14), fill="white")
    card_canvas.create_text(600, 400, text=f"CVV: {card_cvv}", font=("Helvetica", 12, "bold"), fill="white")
    card_window.mainloop()

def create_personal_loan(personal_number, data):
    customer_data = data["users"][personal_number]

    if "loans" not in customer_data:
        customer_data["loans"] = []
    
    if len(customer_data["loans"]) >= 2:
        print("You already have the maximum of 2 loans.")
        time.sleep(3)
        return
    
    current_balance = customer_data["balance"]
    max_personal_loan = 1.5 * current_balance
    
    interest_rate = 12.0
    
    loan_name = input("What would you like to name your loan request as? ").strip()
    clear_console()
    
    try:
        loan_amount = float(input("How much loan are you requesting for your personal expense in SEK? ").strip())
        if loan_amount > max_personal_loan:
            print(f"Loan amount exceeds the maximum allowed limit of {max_personal_loan:.2f} SEK based on your current balance of {current_balance:.2f} SEK.")
            input("Press Enter to return...")
            return
    except ValueError:
        print("Invalid loan amount.")
        return
    
    clear_console()
    
    loan_description = input("What are you using this loan for? \n\n").strip()
    
    clear_console()

#loan term can be changed as it must be discussed and then implemented
    contract = f"""  You must print the following and sign it!
    ---------------------------------------------
    LOAN AGREEMENT
    ---------------------------------------------
    Date: {datetime.now().strftime('%Y-%m-%d')}

    Borrower: {data["users"].get(personal_number)['first_name']} {data["users"].get(personal_number)['last_name']}

    Loan Details:
    ---------------------------------------------
    Loan Amount: SEK{loan_amount}
    Interest Rate: 12%
    Loan Term: 10 years 
    Purpose: {loan_description}

    Agreement:
    ---------------------------------------------
    1. The borrower agrees to repay the loan amount along with the interest as per the repayment schedule.
    2. Failure to comply with the repayment terms may result in additional charges and legal action. 
        With the asset being loaned for being seized
    3. The borrower has read and understood all terms and conditions of this loan agreement.

    Signature:
    ---------------------------------------------
    Borrower Signature: _________________________

    Lender Signature: ___________________________

    """
    print(contract)

    print("Processing your loan request...")
    time.sleep(3)

    clear_console()
    customer_data["loans"].append({
        "loan_name" : loan_name,
        "amount": loan_amount,
        "interest rate": interest_rate,
        "description": loan_description,
        "approved": False,
        "Start_Date" : datetime.now().strftime('%Y-%m-%d')
    })
    save_data(data)
    
    print(f"Loan '{loan_name}' has been successfully created and is awaiting approval. Returning to extras menu...")
    
    time.sleep(3)

def create_mortgage_loan(personal_number, data):
    user = data["users"].get(personal_number)
    
    if not user:
        print("User not found.")
        return

    if "loans" in user:
        if len(user["loans"]) >= 2:
            print("Error: User is only allowed two loans.")
            time.sleep(1)
            return
    
    expected_income = float(input("Enter your expected income (monthly) in SEK: "))
    annual_income = expected_income * 12
    max_loan_amount = annual_income * 5  # Loan cap at 5x annual income
    
    print(f"\nBased on your expected annual income ({annual_income:.2f} SEK), you can apply for a mortgage up to {max_loan_amount:.2f} SEK.")
    
    try:
        loan_amount = float(input("Enter the loan amount you wish to apply for: "))
        if loan_amount > max_loan_amount:
            print("Loan request exceeds the allowable limit based on your income.")
            return
    except ValueError:
        print("Invalid input for loan amount.")
        return
    
    if loan_amount <= 500000:
        interest_rate = 5.0  # 5% for small loans
    elif loan_amount <= 2000000:
        interest_rate = 3.5  # 3.5% for medium loans
    else:
        interest_rate = 2.0  # 2% for large loans
    
    print(f"\nThe interest rate for your loan of {loan_amount:.2f} SEK will be {interest_rate:.1f}%.")
    
    loan_purpose = input("Enter the purpose of the mortgage (e.g., buying a house): ")
    
    contract = f"""  You must print the following and sign it!
    ---------------------------------------------
    LOAN AGREEMENT
    ---------------------------------------------
    Date: {datetime.now().strftime('%Y-%m-%d')}

    Borrower: {data["users"].get(personal_number)['first_name']} {data["users"].get(personal_number)['last_name']}

    Loan Details:
    ---------------------------------------------
    Loan Amount: SEK{loan_amount}
    Interest Rate: {interest_rate}
    Loan Term: 10 years 
    Purpose: {loan_purpose}

    Agreement:
    ---------------------------------------------
    1. The borrower agrees to repay the loan amount along with the interest as per the repayment schedule.
    2. Failure to comply with the repayment terms may result in additional charges and legal action. 
        With the asset being loaned for being seized
    3. The borrower has read and understood all terms and conditions of this loan agreement.

    Signature:
    ---------------------------------------------
    Borrower Signature: _________________________

    Lender Signature: ___________________________

    """
    print(contract)
    
    print("\nProcessing your mortgage loan request...")
    time.sleep(2)
    
    if "loans" not in user:
        user["loans"] = []
    
    user["loans"].append({
        "loan_name": "Mortgage Loan",
        "amount": loan_amount,
        "interest_rate": interest_rate,
        "annual income": annual_income,
        "description": loan_purpose,
        "approved": False,
        "Start_Date": datetime.now().strftime('%Y-%m-%d')
    })
    
    save_data(data)
    print(f"Mortgage Loan of {loan_amount:.2f} SEK created successfully at an interest rate of {interest_rate:.1f}% and is pending approval.")

def pay_loan(personal_number, data):
    update_loan_interest_daily(personal_number, data)
    user = data["users"].get(personal_number)

    # Check if the user exists and has loans
    if not user:
        print("User not found.")
        input("\nPress Enter to go back to the previous menu.")
        return
    if "loans" not in user or not user["loans"]:
        print("No loans found for this user.")
        input("\nPress Enter to go back to the previous menu.")
        return

    print("\n--- Outstanding Loans ---")
    for idx, loan in enumerate(user["loans"], start=1):
        approval_status = "Approved" if loan.get("approved") else "Not Approved"
        print(f"{idx}. Loan Name: {loan['loan_name']}, Amount: {loan['amount']:.2f} SEK, Status: {approval_status}")

    try:
        loan_index = int(input("\nSelect a loan to pay (enter the loan number): ")) - 1
        if loan_index < 0 or loan_index >= len(user["loans"]):
            print("Invalid loan selection.")
            input("\nPress Enter to go back to the previous menu.")
            return
        loan = user["loans"][loan_index]
    except ValueError:
        print("Invalid input. Please enter a number.")
        input("\nPress Enter to go back to the previous menu.")
        return

    # Check if the loan is approved
    if not loan.get("approved"):
        print(f"Loan '{loan['loan_name']}' is not approved yet. Payment cannot be processed.")
        input("\nPress Enter to go back to the previous menu.")
        return

    # Payment process
    try:
        print(f"\nSelected Loan: {loan['loan_name']}, Outstanding Amount: {loan['amount']:.2f} SEK, Status: Approved")
        payment = float(input("Enter the payment amount: "))
        if payment <= 0:
            print("Payment must be a positive amount.")
            input("\nPress Enter to go back to the previous menu.")
            return
        if payment > user["balance"]:
            print("Insufficient balance to make this payment.")
            input("\nPress Enter to go back to the previous menu.")
            return

        # Full loan repayment
        if payment >= loan["amount"]:
            user["balance"] -= loan["amount"]
            user["loans"].remove(loan)
            print(f"Loan '{loan['loan_name']}' fully paid! Your updated balance is: {user['balance']:.2f} SEK.")
        else:
            # Partial payment
            loan["amount"] -= payment
            user["balance"] -= payment
            print(f"Partial payment made. Remaining loan balance: {loan['amount']:.2f} SEK.")
            print(f"Updated account balance: {user['balance']:.2f} SEK.")
        
        # Save updated data
        save_data(data)

    except ValueError:
        print("Invalid payment amount. Please enter a valid number.")

    input("\nPress Enter to go back to the previous menu.")

def force_execute_in_order(*functions):
    for func in functions:
        func()

def update_loan_interest_daily(personal_number, data):
    user = data["users"].get(personal_number)

    if not user or "loans" not in user:
        print("No loans found for this user.")
        return

    for loan in user["loans"]:
        if loan.get("approved"):
            start_date = datetime.strptime(loan["start_date"], "%Y-%m-%d")
            today = datetime.now()

            # Calculate the number of days passed since the last update
            days_passed = (today - start_date).days

            if days_passed > 0:
                principal = loan["amount"]
                annual_rate = loan.get("interest_rate", 0)

                if annual_rate == 0:
                    continue

                daily_rate = (1 + annual_rate / 100) ** (1 / 365) - 1  # Convert annual rate to daily rate
                new_amount = principal * ((1 + daily_rate) ** days_passed)

                # Update loan details
                loan["amount"] = round(new_amount, 2)
                loan["Start_Date"] = today.strftime("%Y-%m-%d")
    save_data(data)

def get_stock_data():

    success_code = 0
    

    while success_code != 200: 

        recent_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')

        url =( f"https://api.polygon.io/v2/aggs/grouped/locale/us/market/stocks/{recent_date}"
            f"?adjusted=true&apiKey=7cDWgESWXFKRL0w1bwZs6BNcpsLOlsP3" )
        
        response = requests.get(url)
        
        success_code = response.status_code

        if success_code == 200:
            data = response.json()
            results = data.get("results", [])

            top_5_stocks = []
            for i in range(5):
                max_volume_stock = None
                max_volume = -1

                for stock in results:
                    if stock['v'] > max_volume and stock not in top_5_stocks:
                        max_volume = stock['v']
                        max_volume_stock = stock
                
                if max_volume_stock:
                    top_5_stocks.append(max_volume_stock)

            with open('stock_data.json', 'w') as file:
                json.dump(top_5_stocks, file, indent=4)
            clear_console()
            print("please wait while the stock opens")
            return top_5_stocks
        else:
            print("Failed to receive the stock data. Please try again.")
            time.sleep(2)
            return


def show_stock_data():
    try:
        
        with open("stock_data.json", 'r') as file:
            stock_data = json.load(file)
    except FileNotFoundError:
        print("Stock data does not exist, please fetch data first.")
        return
    
    stock_names = [stock['T'] for stock in stock_data]
    open_prices = [stock['o'] for stock in stock_data]
    close_prices = [stock['c'] for stock in stock_data]
    high_prices = [stock['h'] for stock in stock_data]
    low_prices = [stock['l'] for stock in stock_data]

    plt.figure(figsize=(12, 7))
    
    
    plt.plot(stock_names, open_prices, label="Open Price", marker='o', linestyle='--', color='blue')
    plt.plot(stock_names, close_prices, label="Close Price", marker='s', linestyle='-', color='green')
    plt.plot(stock_names, high_prices, label="High Price", marker='^', linestyle=':', color='red')
    plt.plot(stock_names, low_prices, label="Low Price", marker='v', linestyle='-.', color='orange')

   
    plt.xlabel("Stock Tickers", fontsize=12)
    plt.ylabel("Price (USD)", fontsize=12)
    plt.title("Top 5 Stock Market Prices", fontsize=14, fontweight='bold')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()

   
    plt.show()
