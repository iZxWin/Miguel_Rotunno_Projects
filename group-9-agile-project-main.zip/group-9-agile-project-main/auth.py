from data_handler import load_data, save_data, generate_account_number
from utils import hash_password, validate_personal_number, clear_console
from admin_operations import admin_menu
import time
from datetime import datetime

def check_password_user(personnumber, try_password):
    
    users_json = load_data()
    hashed_try = hash_password(try_password)
    
    if hashed_try == users_json["users"][personnumber]["password"]:
        return True
    else:
        return False

def check_password_admin(personnumber, try_password):
    
    admin_json = load_data()
    hashed_try = hash_password(try_password)
    
    if hashed_try == admin_json["admins"][personnumber]["password"]:
        return True
    else:
        return False

def user_login():
    from menus import user_menu
    data = load_data()
    user_id = input("Enter personalnumber (YYYYMMDD-XXXX): ")
 
    if user_id in data["users"]:
        login_attempts = 0
        max_attempts = 5

        while login_attempts < max_attempts:
            clear_console()
            user_password = input("Enter password: ")

            if check_password_user(user_id, user_password):
                print("Login successful!")
                time.sleep(1)
                name = data["users"][user_id]["first_name"]
                user_menu(user_id, name)
                return  
            
            login_attempts += 1
            if login_attempts < max_attempts:
                delay = 2 ** login_attempts
                print(f"Wrong password, please try again. Attempts left: {max_attempts - login_attempts}. Waiting {delay} seconds before next attempt.")
                time.sleep(delay)

        print("Too many failed login attempts. Login is temporarily frozen. Please try again later.")
        time.sleep(25)
        
    else:
        if not validate_personal_number(user_id):
            clear_console()
            print("Invalid personal number format! Please use YYYYMMDD-XXXX.")
        else:
            clear_console()
            print("No user with the inputted personal number, try again.")

        user_login()

def admin_login():
    data = load_data()
    admin_id = input("Enter personalnumber (YYYYMMDD-XXXX): ")

    if admin_id in data["admins"]:
        login_attempts = 0
        max_attempts = 5

        while login_attempts < max_attempts:
            clear_console()
            admin_password = input("Enter password: ")

            if check_password_admin(admin_id, admin_password):
                print("Login successful!")
                time.sleep(1)
                admin_menu(data)
                return

            login_attempts += 1
            if login_attempts < max_attempts:
                delay = 2 ** login_attempts
                print(f"Wrong password, please try again. Attempts left: {max_attempts - login_attempts}. Waiting {delay} seconds before next attempt.")
                time.sleep(delay)

        print("Too many failed login attempts. Login is temporarily frozen. Please try again later.")
        time.sleep(25)
    else:
        if not validate_personal_number(admin_id):
            clear_console()
            print("Invalid personal number format! Please use YYYYMMDD-XXXX.")
        else:
            clear_console()
            print("No admin with said personal number, try again.")

        return
 
def get_password_confirmation():

    password = input("Enter password: ").strip()
    clear_console()
    confirm_password = input("Confirm password: ").strip()
    clear_console()
    
    while password != confirm_password:
        print("Passwords do not match! Please try again.")
        password = input("Enter password: ").strip()
        clear_console()
        confirm_password = input("Confirm password: ").strip()
        clear_console()
    
    return password

def get_valid_personal_number(users):
    personal_number = input("Enter personal number (YYYYMMDD-XXXX): ").strip()
    year_str = personal_number[:4]
    year_int = int(year_str)
    current_year = datetime.now().year
    if current_year - year_int < 18:
        print("You must be at least 18 years old to register.")
        time.sleep(2)
        return False
    
    clear_console()
    
    while not validate_personal_number(personal_number) or personal_number in users:
        if not validate_personal_number(personal_number):
            print("Invalid personal number format! Please use YYYYMMDD-XXXX.")
        elif personal_number in users:
            print("Personal number already exists! Please try another.")
            
        personal_number = input("Enter personal number (YYYYMMDD-XXXX): ").strip()
        clear_console()
        
    return personal_number

def user_registration():
    from utils import generate_card_data

    data = load_data()
    users = data["users"]
    print("--- User Registration ---\n")

    first_name = input("Enter first name: ").strip()
    clear_console()
    last_name = input("Enter last name: ").strip()
    clear_console()

    personal_number = get_valid_personal_number(users)
    if not personal_number:
        return
    initial_balance = get_valid_balance()
    hashed_password = get_password_confirmation()
    security_question1_answer = input("This is a security question for later use. What is your favourite colour? ")
    card_details = generate_card_data()
    
    # updating each user's json based on their inputs
    users[personal_number] = {
        "first_name": first_name,
        "last_name": last_name,
        "personal_number": personal_number,
        "password": hash_password(hashed_password),
        "security_question1": security_question1_answer,
        "balance": initial_balance,
        "account_number": generate_account_number(),
        "card_details": card_details,
        "transaction_history": [],
        "favorites": "",
        "child_accounts": {}

    }
    save_data(data)
    print("Registration successful!")
    time.sleep(2)
    
def reset_password():
    data = load_data()
    users = data["users"]
    personal_number = input("Enter your personal number (YYYYMMDD-XXXX): ")
    
    if personal_number not in users:
        return print("Error: the personal nubmer is incorrect. User doesn't exit.")
    
    else:
        colour_question_answer = input("What is your favourite colour? ")

        if colour_question_answer not in users[personal_number]["security_question1"]:
            print("Your answer is incorrect! Failed to reset password, returning to the login menu.")
            time.sleep(5)
            return 
        
        else:
            new_password = get_password_confirmation()
            # updating the user data with the new password and hashing it
            users[personal_number]["password"] = hash_password(new_password)
            
def get_valid_balance():
    valid_balance = False
    while not valid_balance:
        try:
            initial_balance = float(input("Enter initial balance in SEK: ").strip())
            clear_console()
            if initial_balance < 0:
                print("Initial balance cannot be negative.")
            else:
                valid_balance = True
        except ValueError:
            print("Invalid balance! Please enter a numeric value.")
    
    return initial_balance