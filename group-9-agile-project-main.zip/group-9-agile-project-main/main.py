from GUIs import mainmenu_gui

def main():
    mainmenu_gui()

if __name__ == "__main__":
    main()