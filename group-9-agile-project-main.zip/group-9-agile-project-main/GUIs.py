import time
import tkinter as tk
from tkinter import messagebox, Scrollbar, Canvas
from menus import handle_user_menu
from auth import admin_login, check_password_admin, reset_password
from data_handler import load_data, save_data
from utils import hash_password
from datetime import datetime

BACKGROUND_COLOR = "#2E3B4E"
BUTTON_TEXT_COLOR = "#000000"
HEADING_COLOR = "#FFFFFF"
SUBHEADING_COLOR = "#A9BCD0"
BUTTON_BACKGROUND = "#CCD3ED"

def create_styled_button(canvas, text, command, x, y):
    button = tk.Button(canvas, text=text, command=command, font=("Helvetica", 12, "bold"),
                       bg=BUTTON_BACKGROUND, fg=BUTTON_TEXT_COLOR, activebackground="#4056A1", width=20, height=2)
    button_window = canvas.create_window(x, y, anchor="center", window=button)
    return button_window

def mainmenu_gui(root=None, mycanvas=None):
    if root is None:
        root = tk.Tk()
        root.title("Main Menu")

    if mycanvas is None:
        mycanvas = tk.Canvas(root, width=800, height=500, bg=BACKGROUND_COLOR)
        mycanvas.pack(fill="both", expand=True)

    # Clear the canvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    # Draw the background
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)

    # Add main menu text
    mycanvas.create_text(400, 100, text="Welcome to SIF Bank", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)
    mycanvas.create_text(400, 160, text="Your Secure Banking Partner", font=("Helvetica", 20), fill=SUBHEADING_COLOR)

    # Define navigation functions
    def switch_to_userlogin():
        user_gui(root, mycanvas)

    def switch_to_adminlogin():
        admin_login_gui(root, mycanvas)

    # Add buttons
    create_styled_button(mycanvas, "User", lambda: switch_to_userlogin(), 400, 250)
    create_styled_button(mycanvas, "Admin", lambda: switch_to_adminlogin(), 400, 300)
    create_styled_button(mycanvas, "Exit", root.destroy, 400, 350)

    # Run the main loop if applicable
    if root is not None:
        root.mainloop()



def user_gui(root, mycanvas):
    # Clear the canvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)

    # Add user login text
    mycanvas.create_text(400, 100, text="User Login", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    # Define navigation functions
    def switch_to_loginwindow():
        userlogin_gui(root, mycanvas)

    def switch_to_forgotpassword_window():
        forgot_password_gui(root, mycanvas)

    # Add buttons
    create_styled_button(mycanvas, "Login", switch_to_loginwindow, 400, 200)
    create_styled_button(mycanvas, "Forget Password", switch_to_forgotpassword_window, 400, 250)
    create_styled_button(mycanvas, "Register", lambda: user_registration_gui(root, mycanvas), 400, 300)
    create_styled_button(mycanvas, "Back to Main Menu", lambda: mainmenu_gui(root, mycanvas), 400, 350)

def userlogin_gui(root, mycanvas, user_id=None):
    from auth import check_password_user

    # Clear the canvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)

    # Add user login text
    mycanvas.create_text(400, 100, text="User Login", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    # Labels and Entry widgets for Personal Number and Password
    personal_number_label = tk.Label(mycanvas, text="Personal Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=BUTTON_TEXT_COLOR)
    mycanvas.create_window(300, 200, anchor="e", window=personal_number_label)

    personal_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    mycanvas.create_window(400, 200, anchor="w", window=personal_number_entry)

    password_label = tk.Label(mycanvas, text="Password", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=BUTTON_TEXT_COLOR)
    mycanvas.create_window(300, 250, anchor="e", window=password_label)

    password_entry = tk.Entry(mycanvas, font=("Helvetica", 14), show="*")
    mycanvas.create_window(400, 250, anchor="w", window=password_entry)

    # Handle login logic
    def handle_login():
        try:
            user_id = personal_number_entry.get()
            user_password = password_entry.get()

            if not user_id or not user_password:
                messagebox.showerror("Login Failed", "Personal Number and Password fields cannot be empty.")
                return

            # Load data and validate user
            data = load_data()
            if user_id in data["users"]:
                if check_password_user(user_id, user_password):
                    logged_in_user_gui(root, mycanvas, user_id)
                else:
                    messagebox.showerror("Login Failed", "Incorrect password. Please try again.")
            else:
                messagebox.showerror("Login Failed", "Invalid user ID or not registered.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")

    # Add buttons
    create_styled_button(mycanvas, "Login", handle_login, 400, 300)
    create_styled_button(mycanvas, "Back to User Menu", lambda: user_gui(root, mycanvas), 400, 350)

def logged_in_user_gui(root, mycanvas, user_id):
    from bank_operations import show_bank_card
    image_source = "./cards/redcard.png"

    # Load user data
    data = load_data()
    user_data = data['users'].get(user_id, {})
    user_name = user_data.get("first_name", "User")

    # Clear the canvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.config(width=800, height=400)  # Reduced height
    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 400, fill=BACKGROUND_COLOR)  # Adjusted height

    # Add user welcome text
    mycanvas.create_text(400, 30, text=f"Welcome, {user_name.capitalize()}", font=("Helvetica", 30), fill=SUBHEADING_COLOR)

    # Define button functions
    def show_balance():
        show_balance_gui(root, mycanvas, user_id)

    def make_transaction():
        transaction_money_gui(root, mycanvas, user_id)

    def transaction_history():
        transaction_history_gui(root, mycanvas, user_id)

    def manage_child_accounts():
        manage_child_accounts_gui(root, mycanvas, user_id)

    def deposit_money():
        deposit_money_gui(mycanvas, user_id, root)

    def withdraw_money():
        withdrawal_gui(mycanvas, user_id, root)

    def create_savings():
        create_savings_account_gui(root, mycanvas, user_id)

    def show_card():
        show_bank_card("./cards/redcard.png", user_id)

    def extras():
        extra_menu_gui(root, mycanvas, user_id)

    def log_out():
        userlogin_gui(root, mycanvas)

    # Add buttons
    create_styled_button(mycanvas, "Show Balance", show_balance, 250, 100)
    create_styled_button(mycanvas, "Make Transaction", make_transaction, 550, 100)
    create_styled_button(mycanvas, "Show Transaction History", transaction_history, 250, 150)
    create_styled_button(mycanvas, "Child's Account", manage_child_accounts, 550, 150)
    create_styled_button(mycanvas, "Make Deposit", deposit_money, 250, 200)
    create_styled_button(mycanvas, "Make Withdrawal", withdraw_money, 550, 200)
    create_styled_button(mycanvas, "Create Savings Account", create_savings, 250, 250)
    create_styled_button(mycanvas, "Show Card", show_card, 550, 250)
    create_styled_button(mycanvas, "Extras", extras, 250, 300)
    create_styled_button(mycanvas, "Log Out", log_out, 550, 300)


def create_savings_account_gui(root, mycanvas, user_id):
   
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Create Savings Account", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    data = load_data()
    user = data["users"].get(user_id, {})
    if not user:
        messagebox.showerror("Error", "User data not found!")
        return

    available_balance = user.get("balance", 0)

    mycanvas.create_text(400, 150, text=f"Available Balance: {available_balance:.2f} SEK", font=("Helvetica", 14), fill=SUBHEADING_COLOR)

    initial_deposit_label = tk.Label(mycanvas, text="Initial Deposit", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    initial_deposit_label_window = mycanvas.create_window(300, 200, anchor="e", window=initial_deposit_label)

    initial_deposit_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    initial_deposit_entry_window = mycanvas.create_window(400, 200, anchor="w", window=initial_deposit_entry)
    
    def create_savings_account(user_id, interest, initial_deposit):
        from data_handler import generate_account_number
        data = load_data()
        users = data.get("users", {})

        if user_id not in users:
            raise ValueError("Error: User account not found.")

        user = users[user_id]
        available_balance = user.get("balance", 0)

        if initial_deposit < 0 or initial_deposit > available_balance:
            raise ValueError("Error: Invalid deposit amount.")

        # Generate a new savings account number
        savings_account_number = generate_account_number()

        # Update user balance and create savings account
        user["balance"] = available_balance - initial_deposit
        user["savings_account"] = {
            "account_number": savings_account_number,
            "balance": initial_deposit,
            "interest": interest,
        }

        # Save updated data
        save_data(data)

        return savings_account_number

    def handle_create_savings_account():
        try:
            initial_deposit = float(initial_deposit_entry.get())

            if initial_deposit < 0 or initial_deposit > available_balance:
                messagebox.showerror("Error", "Invalid deposit amount!")
                return

            create_savings_account(user_id, 0.01, initial_deposit)
            messagebox.showinfo("Success", "Savings account created successfully!")
            logged_in_user_gui(root, mycanvas, user_id)

        except ValueError:
            messagebox.showerror("Error", "Please enter valid numeric values.")

    create_button = tk.Button(mycanvas, text="Create Account", command=handle_create_savings_account, width=20, height=2, bg=HEADING_COLOR)
    create_button_window = mycanvas.create_window(400, 250, anchor="center", window=create_button)

    back_button = tk.Button(mycanvas, text="Back", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 300, anchor="center", window=back_button)

def forgot_password_gui(root, mycanvas):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()    

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Forgot Password", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    # Creating the labels and entry boxes for personal number and password
    personal_number_label = tk.Label(mycanvas, text="Personal Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    personal_number_label_window = mycanvas.create_window(300, 200, anchor="e", window=personal_number_label)

    personal_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    personal_number_entry_window = mycanvas.create_window(400, 200, anchor="w", window=personal_number_entry)

    colour_question_answer_label = tk.Label(mycanvas, text="What is your favourite colour?", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    colour_question_answer_label_window = mycanvas.create_window(300, 250, anchor="e", window=colour_question_answer_label)
    colour_question_answer_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    colour_question_answer_entry_window = mycanvas.create_window(400, 250, anchor="w", window=colour_question_answer_entry)

    def handle_reset_password():
        personal_number = personal_number_entry.get()
        colour_question_answer = colour_question_answer_entry.get()
        data = load_data()
        users = data["users"]    
    
        if personal_number not in users:
            messagebox.showerror("Error", "No user with the inputted personal number.")
        else:
            if colour_question_answer not in users[personal_number]["security_question1"]:
                messagebox.showerror("Error", "Security question answer is incorrect.")
                time.sleep(5)
            else:
                for widget in mycanvas.winfo_children():
                    widget.destroy()
    
                mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
                mycanvas.create_text(400, 100, text="Reset password", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

                new_password_label= tk.Label(mycanvas, text="Enter the new password below", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
                new_password_label_window = mycanvas.create_window(300, 300, anchor="e", window=new_password_label)
                new_password_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
                new_password_entry_window = mycanvas.create_window(400, 300, anchor="w", window=new_password_entry)

                confirmed_password_label = tk.Label(mycanvas, text="Confirm the new password below", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
                confirmed_password_label_window = mycanvas.create_window(300, 350, anchor="e", window=confirmed_password_label)
                confirmed_password_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
                confirmed_password_entry_window = mycanvas.create_window(400, 350, anchor="w", window=confirmed_password_entry)

                def confirm_password_reset():
                    new_password = new_password_entry.get()
                    confirmed_password = confirmed_password_entry.get()
                    
                    if new_password == confirmed_password:
                        users[personal_number]["password"] = hash_password(new_password)
                        save_data(data)
                        messagebox.showinfo("Success", "Password has been reset successfully.")
                        user_gui(root, mycanvas)
                    else:
                        messagebox.showerror("Error", "Passwords do not match. Please try again.")

                confirm_button = tk.Button(mycanvas, text="Confirm Password Reset", command=confirm_password_reset, width=20, height=2, bg=HEADING_COLOR)
                mycanvas.create_window(400, 400, anchor="center", window=confirm_button)
                
                back_button = tk.Button(mycanvas, text="Back", command=lambda : user_gui(root, mycanvas), width=20, height=2, bg=HEADING_COLOR)
                back_button_window = mycanvas.create_window(400, 450, anchor="center", window=back_button)

    # Creating the buttons
    reset_password_button = tk.Button(mycanvas, text="Reset Password", command=handle_reset_password, width=20, height=2, bg=HEADING_COLOR)
    reset_password_button_window = mycanvas.create_window(400, 300, anchor="center", window=reset_password_button)

    # Button to go back to user menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: user_gui(root, mycanvas), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def user_registration_gui(root, mycanvas):
    from utils import generate_card_data
    from data_handler import load_data, save_data
    from auth import hash_password, generate_account_number

    #Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 600, fill=BACKGROUND_COLOR)  # Increased height to 600
    mycanvas.create_text(400, 50, text="User Registration", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    #fields for user registration
    fields = {
        "First Name": tk.Entry(mycanvas, font=("Helvetica", 14)),
        "Last Name": tk.Entry(mycanvas, font=("Helvetica", 14)),
        "Personal Number": tk.Entry(mycanvas, font=("Helvetica", 14)),
        "Initial Balance": tk.Entry(mycanvas, font=("Helvetica", 14)),
        "Password": tk.Entry(mycanvas, font=("Helvetica", 14), show="*"),
        "Security Question": tk.Entry(mycanvas, font=("Helvetica", 14)),
    }

    y = 100
    for label_text, entry_widget in fields.items():
        label = tk.Label(mycanvas, text=label_text, font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
        label_window = mycanvas.create_window(250, y, anchor="e", window=label)

        entry_window = mycanvas.create_window(300, y, anchor="w", window=entry_widget)
        y += 50

    #hints for user registration
    personal_number_hint = tk.Label(mycanvas, text="Format: YYYYMMDD-####", font=("Helvetica", 10), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    personal_number_hint_window = mycanvas.create_window(550, 200, anchor="w", window=personal_number_hint)

    favorite_color_hint = tk.Label(mycanvas, text="Favorite color", font=("Helvetica", 10), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    favorite_color_hintt_window = mycanvas.create_window(140, 370, anchor="w", window=favorite_color_hint)

    def register_user():
        #load data
        data = load_data()
        users = data["users"]

        #get user input
        first_name = fields["First Name"].get().strip()
        last_name = fields["Last Name"].get().strip()
        personal_number = fields["Personal Number"].get().strip()
        initial_balance = fields["Initial Balance"].get().strip()
        password = fields["Password"].get().strip()
        security_answer = fields["Security Question"].get().strip()

        #validate user input
        if not first_name or not last_name or not personal_number or not password:
            messagebox.showerror("Error", "All fields are required!")
            return

        if personal_number in users:
            messagebox.showerror("Error", "Personal number already exists! Please try another.")
            return

        if not initial_balance.isdigit() or int(initial_balance) < 0:
            messagebox.showerror("Error", "Invalid balance amount!")
            return

        #generating card details and hashing password
        card_details = generate_card_data()
        hashed_password = hash_password(password)

        #add user to data
        users[personal_number] = {
            "first_name": first_name,
            "last_name": last_name,
            "personal_number": personal_number,
            "password": hashed_password,
            "security_question1": security_answer,
            "balance": int(initial_balance),
            "account_number": generate_account_number(),
            "card_details": card_details,
            "transaction_history": [],
            "favorites": "",
            "child_accounts": {}
        }

        save_data(data)  #save data
        print("Registration successful!")
        mainmenu_gui(root, mycanvas)  #go back to main menu

    #button to register user
    register_button = tk.Button(mycanvas, text="Register", command=register_user, width=20, height=2, bg=HEADING_COLOR)
    register_button_window = mycanvas.create_window(400, y + 30, anchor="center", window=register_button)

    #button to go back to user menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: user_gui(root, mycanvas), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, y + 80, anchor="center", window=back_button)

def transaction_money_gui(root, mycanvas, user_id):
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Transaction", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    # Labels and entry boxes for the transaction
    account_number_label = tk.Label(mycanvas, text="Account Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    account_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    mycanvas.create_window(300, 120, anchor="e", window=account_number_label)
    mycanvas.create_window(360, 120, anchor="w", window=account_number_entry)

    amount_label = tk.Label(mycanvas, text="Amount", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    mycanvas.create_window(300, 170, anchor="e", window=amount_label)
    mycanvas.create_window(360, 170, anchor="w", window=amount_entry)

    transaction_message_label = tk.Label(mycanvas, text="Message", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    transaction_message_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    mycanvas.create_window(300, 220, anchor="e", window=transaction_message_label)
    mycanvas.create_window(360, 220, anchor="w", window=transaction_message_entry)
                           

    # logic for handling the transaction
    def handle_transaction():
        data = load_data()
        user_data = data["users"][user_id]
        user_balance = user_data["balance"]

        account_number = account_number_entry.get().strip()
        amount = amount_entry.get().strip()

        # validation of account number
        recipient_data = None
        for user in data["users"].values():
            if str(user["account_number"]) == account_number:
                recipient_data = user
                break

        if recipient_data is None:
            messagebox.showerror("Error", "Account number not found.")
            return

        # validation of amount
        if not amount.isdigit() or int(amount) <= 0:
            messagebox.showerror("Error", "Invalid amount.")
            return
        elif int(amount) > user_balance:
            messagebox.showerror("Error", "Insufficient funds.")
            return

        # update the balances
        amount = int(amount)
        user_data["balance"] -= amount
        recipient_data["balance"] += amount

        # register the transaction
        transaction_date = datetime.now().strftime("%Y-%m-%d")
        user_data["transaction_history"].append({
            "type": transaction_message_entry.get(),
            "amount": amount,
            "recipient": recipient_data["account_number"],
            "date": transaction_date,
            "new_balance": user_data["balance"]
        })
        recipient_data["transaction_history"].append({
            "type": transaction_message_entry.get(),
            "amount": amount,
            "sender": user_data["account_number"],
            "date": transaction_date,
            "new_balance": recipient_data["balance"]
        })

        save_data(data)
        messagebox.showinfo("Success", "Transaction successful.")
        logged_in_user_gui(root, mycanvas, user_id)

    # Button to confirm the transaction
    transaction_button = tk.Button(mycanvas, text="Transaction", command=handle_transaction, width=20, height=2, bg=HEADING_COLOR)
    mycanvas.create_window(400, 300, anchor="center", window=transaction_button)

    # Button to go back to user menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    mycanvas.create_window(400, 350, anchor="center", window=back_button)

def transaction_history_gui(root, mycanvas, user_id):

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Transaction History", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    data = load_data()
    user_data = data["users"][user_id]
    transaction_history = user_data["transaction_history"]

    y = 100
    for transaction in transaction_history:
        transaction_text = f"{transaction['date']} - {transaction['type']} - {transaction['amount']} sek"
        transaction_label = tk.Label(mycanvas, text=transaction_text, font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg="#ffffff")
        mycanvas.create_window(400, y, anchor="center", window=transaction_label)
        y += 30

    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    mycanvas.create_window(400, 350, anchor="center", window=back_button)

def extra_menu_gui(root, mycanvas,user_id):
    from utils import generate_qr_code
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()    

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Extras", font=("Helvetica", 40, "bold"), fill=HEADING_COLOR)

    # Creating the buttons
    personal_loan_button = tk.Button(mycanvas, text="Personal loan", command=lambda: personal_loan_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    personal_loan_window = mycanvas.create_window(400, 150, anchor="center", window=personal_loan_button)

    mortgage_loan_button = tk.Button(mycanvas, text="Mortgage Loan", command=lambda: mortgage_loan_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    mortgage_loan_window = mycanvas.create_window(400, 200, anchor="center", window=mortgage_loan_button)
    
    pay_loans_buttom = tk.Button(mycanvas, text="Pay loans", command=lambda: pay_loan_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    pay_loans_window = mycanvas.create_window(400, 250, anchor="center", window=pay_loans_buttom)

    survey_button = tk.Button(mycanvas, text="Bank survey", command=lambda: generate_qr_code(), width=20, height=2, bg=HEADING_COLOR)
    survey_button_window = mycanvas.create_window(400, 300, anchor="center", window=survey_button)

    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root,mycanvas,user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def personal_loan_gui(root, mycanvas, user_id):
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Personal Loan Request", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    data = load_data()
    user_data = data["users"].get(user_id, {})

    if not user_data:
        messagebox.showerror("Error", "User data not found!")
        return

    current_balance = user_data.get("balance", 0)
    max_personal_loan = 1.5 * current_balance

    # Display user's current balance and max loan amount
    mycanvas.create_text(400, 100, text=f"Current Balance: {current_balance:.2f} SEK", font=("Helvetica", 14), fill=HEADING_COLOR)
    mycanvas.create_text(400, 130, text=f"Max Loan Amount: {max_personal_loan:.2f} SEK", font=("Helvetica", 14), fill=HEADING_COLOR)

    # Loan name entry
    loan_name_label = tk.Label(mycanvas, text="Loan Name", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    loan_name_label_window = mycanvas.create_window(300, 170, anchor="e", window=loan_name_label)

    loan_name_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    loan_name_entry_window = mycanvas.create_window(400, 170, anchor="w", window=loan_name_entry)

    # Loan amount entry
    loan_amount_label = tk.Label(mycanvas, text="Loan Amount", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    loan_amount_label_window = mycanvas.create_window(300, 210, anchor="e", window=loan_amount_label)

    loan_amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    loan_amount_entry_window = mycanvas.create_window(400, 210, anchor="w", window=loan_amount_entry)

    # Loan description entry
    loan_description_label = tk.Label(mycanvas, text="Loan Purpose", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    loan_description_label_window = mycanvas.create_window(300, 250, anchor="e", window=loan_description_label)

    loan_description_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    loan_description_entry_window = mycanvas.create_window(400, 250, anchor="w", window=loan_description_entry)

    def submit_personal_loan():
        try:
            loan_name = loan_name_entry.get().strip()
            loan_amount = float(loan_amount_entry.get().strip())
            loan_description = loan_description_entry.get().strip()

            if not loan_name or not loan_description:
                messagebox.showerror("Error", "All fields must be filled.")
                return

            if loan_amount <= 0 or loan_amount > max_personal_loan:
                messagebox.showerror("Error", f"Loan amount must be between 0 and {max_personal_loan:.2f} SEK.")
                return

            if "loans" not in user_data:
                user_data["loans"] = []

            if len(user_data["loans"]) >= 2:
                messagebox.showerror("Error", "You already have the maximum of 2 loans.")
                return

            # Append the loan data
            user_data["loans"].append({
                "loan_name": loan_name,
                "amount": loan_amount,
                "interest_rate": 12.0,
                "description": loan_description,
                "approved": False,
                "start_date": datetime.now().strftime('%Y-%m-%d'),
            })

            save_data(data)
            messagebox.showinfo("Success", f"Loan '{loan_name}' requested successfully and is awaiting approval.")
            logged_in_user_gui(root, mycanvas, user_id)

        except ValueError:
            messagebox.showerror("Error", "Invalid loan amount entered.")

    # Submit and back buttons
    submit_button = tk.Button(mycanvas, text="Submit Loan Request", command=submit_personal_loan, width=20, height=2, bg=HEADING_COLOR)
    submit_button_window = mycanvas.create_window(400, 300, anchor="center", window=submit_button)

    back_button = tk.Button(mycanvas, text="Back to Extras Menu", command=lambda: extra_menu_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def mortgage_loan_gui(root, mycanvas, user_id):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Apply for a Mortgage Loan", font=("Helvetica", 30), fill=HEADING_COLOR)

    data = load_data()
    user_data = data["users"].get(user_id)

    if not user_data:
        messagebox.showerror("Error", "User data not found!")
        return

    # Check if the user already has two loans
    if "loans" in user_data and len(user_data["loans"]) >= 2:
        messagebox.showerror("Error", "You already have the maximum of two loans.")
        extra_menu_gui(root, mycanvas, user_id)
        return

    # Expected income entry
    income_label = tk.Label(mycanvas, text="Expected Monthly Income (SEK)", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    income_label_window = mycanvas.create_window(300, 100, anchor="e", window=income_label)

    income_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    income_entry_window = mycanvas.create_window(400, 100, anchor="w", window=income_entry)

    # Calculate button
    calculate_button = tk.Button(mycanvas, text="Calculate Max Loan", width=20, height=2, bg=HEADING_COLOR)
    calculate_button_window = mycanvas.create_window(400, 140, anchor="center", window=calculate_button)

    # Max loan label (initially empty, will be updated dynamically)
    max_loan_label = tk.Label(mycanvas, text="", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    max_loan_label_window = mycanvas.create_window(400, 180, anchor="center", window=max_loan_label)

    # Loan amount entry
    loan_label = tk.Label(mycanvas, text="Loan Amount (SEK)", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    loan_label_window = mycanvas.create_window(300, 220, anchor="e", window=loan_label)

    loan_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    loan_entry_window = mycanvas.create_window(400, 220, anchor="w", window=loan_entry)

    # Loan purpose entry
    purpose_label = tk.Label(mycanvas, text="Loan Purpose", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    purpose_label_window = mycanvas.create_window(300, 270, anchor="e", window=purpose_label)

    purpose_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    purpose_entry_window = mycanvas.create_window(400, 270, anchor="w", window=purpose_entry)

    def calculate_max_loan():
        try:
            expected_income = float(income_entry.get())
            annual_income = expected_income * 12
            max_loan_amount = annual_income * 5  # Loan cap at 5x annual income
            max_loan_label.config(text=f"Maximum Loan Amount: {max_loan_amount:.2f} SEK")
        except ValueError:
            max_loan_label.config(text="Invalid income value. Please enter a number.")

    calculate_button.config(command=calculate_max_loan)

    def submit_mortgage_loan():
        try:
            expected_income = float(income_entry.get())
            loan_amount = float(loan_entry.get())
            loan_purpose = purpose_entry.get().strip()

            # Validate inputs
            if not loan_purpose:
                messagebox.showerror("Error", "Loan purpose cannot be empty.")
                return

            annual_income = expected_income * 12
            max_loan_amount = annual_income * 5

            if loan_amount > max_loan_amount:
                messagebox.showerror("Error", f"Loan amount exceeds the allowable limit of {max_loan_amount:.2f} SEK.")
                return

            # Determine interest rate
            if loan_amount <= 500000:
                interest_rate = 5.0
            elif loan_amount <= 2000000:
                interest_rate = 3.5
            else:
                interest_rate = 2.0

            # Confirm loan details
            confirmation = messagebox.askyesno(
                "Confirm Loan",
                f"Loan Amount: {loan_amount:.2f} SEK\n"
                f"Interest Rate: {interest_rate:.1f}%\n"
                f"Loan Purpose: {loan_purpose}\n\n"
                "Do you want to proceed with this loan application?"
            )

            if not confirmation:
                return

            # Process the loan
            if "loans" not in user_data:
                user_data["loans"] = []

            user_data["loans"].append({
                "loan_name": "Mortgage Loan",
                "amount": loan_amount,
                "interest_rate": interest_rate,
                "annual income": annual_income,
                "description": loan_purpose,
                "approved": False,
                "Start_Date": datetime.now().strftime('%Y-%m-%d'),
            })

            save_data(data)
            messagebox.showinfo("Success", f"Mortgage loan of {loan_amount:.2f} SEK created successfully and is pending approval.")
            extra_menu_gui(root, mycanvas, user_id)

        except ValueError:
            messagebox.showerror("Error", "Please enter valid numeric values for income and loan amount.")

    # Submit and back buttons
    submit_button = tk.Button(mycanvas, text="Submit Loan Request", command=submit_mortgage_loan, width=20, height=2, bg=HEADING_COLOR)
    submit_button_window = mycanvas.create_window(400, 320, anchor="center", window=submit_button)

    back_button = tk.Button(mycanvas, text="Back to Extras Menu", command=lambda: extra_menu_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 370, anchor="center", window=back_button)

def pay_loan_gui(root, mycanvas, user_id):
    from bank_operations import update_loan_interest_daily
    # Update loan interests before displaying loans
    data = load_data()
    update_loan_interest_daily(user_id, data)  # Update loans with daily interest
    save_data(data)  # Save updated loan amounts

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Pay Loan", font=("Helvetica", 30), fill=HEADING_COLOR)

    user_data = data["users"].get(user_id)

    if not user_data or "loans" not in user_data or not user_data["loans"]:
        messagebox.showinfo("No Loans", "You currently have no outstanding loans.")
        extra_menu_gui(root, mycanvas, user_id)
        return

    # Display loans
    y_position = 100
    loans = user_data["loans"]

    def pay_selected_loan(loan_index):
        loan = loans[loan_index]

        if not loan.get("approved"):
            messagebox.showinfo("Not Approved", f"Loan '{loan['loan_name']}' is not approved yet. Payment cannot be processed.")
            return

        def process_payment():
            try:
                payment = float(payment_entry.get())
                if payment <= 0:
                    messagebox.showerror("Invalid Amount", "Payment must be a positive amount.")
                    return
                if payment > user_data["balance"]:
                    messagebox.showerror("Insufficient Funds", "You don't have enough balance to make this payment.")
                    return

                # Handle full or partial payment
                if payment >= loan["amount"]:
                    user_data["balance"] -= loan["amount"]
                    user_data["loans"].remove(loan)
                    messagebox.showinfo("Loan Paid", f"Loan '{loan['loan_name']}' fully paid!")
                else:
                    loan["amount"] -= payment
                    user_data["balance"] -= payment
                    messagebox.showinfo("Partial Payment", f"Partial payment made. Remaining loan balance: {loan['amount']:.2f} SEK.")

                save_data(data)
                pay_loan_gui(root, mycanvas, user_id)

            except ValueError:
                messagebox.showerror("Error", "Please enter a valid payment amount.")

        # Clear and display payment options
        for widget in mycanvas.winfo_children():
            widget.destroy()

        mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
        mycanvas.create_text(400, 50, text=f"Pay Loan: {loan['loan_name']}", font=("Helvetica", 30), fill=HEADING_COLOR)
        mycanvas.create_text(400, 120, text=f"Outstanding Amount: {loan['amount']:.2f} SEK", font=("Helvetica", 14), fill=HEADING_COLOR)
        mycanvas.create_text(400, 150, text=f"Current Balance: {user_data['balance']:.2f} SEK", font=("Helvetica", 14), fill=HEADING_COLOR)

        payment_label = tk.Label(mycanvas, text="Payment Amount", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
        payment_label_window = mycanvas.create_window(300, 200, anchor="e", window=payment_label)

        payment_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
        payment_entry_window = mycanvas.create_window(400, 200, anchor="w", window=payment_entry)

        pay_button = tk.Button(mycanvas, text="Make Payment", command=process_payment, width=20, height=2, bg=HEADING_COLOR)
        pay_button_window = mycanvas.create_window(400, 250, anchor="center", window=pay_button)

        back_button = tk.Button(mycanvas, text="Back to Loan List", command=lambda: pay_loan_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
        back_button_window = mycanvas.create_window(400, 300, anchor="center", window=back_button)

    # Display loans in buttons
    for idx, loan in enumerate(loans):
        loan_text = f"{loan['loan_name']} - {loan['amount']:.2f} SEK - {'Approved' if loan.get('approved') else 'Not Approved'}"
        loan_button = tk.Button(mycanvas, text=loan_text, command=lambda idx=idx: pay_selected_loan(idx), width=60, height=2, bg=HEADING_COLOR)
        loan_button_window = mycanvas.create_window(400, y_position, anchor="center", window=loan_button)
        y_position += 50

    # Back button
    back_button = tk.Button(mycanvas, text="Back to Extras Menu", command=lambda: extra_menu_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, y_position + 50, anchor="center", window=back_button)

def deposit_money_gui(mycanvas, user_id, root):
        # Clear the mycanvas
        for widget in mycanvas.winfo_children():
            widget.destroy()

        mycanvas.pack(fill="both", expand=True)
        mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
        mycanvas.create_text(400, 100, text="Make Deposit", font=("Helvetica", 40), fill=HEADING_COLOR)

        tk.Label(mycanvas, text="Enter amount to deposit:", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR).place(x=300, y=200, anchor="e")
        amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
        amount_entry.place(x=310, y=200, anchor="w")

        def confirm_deposit():
            try:
                amount = float(amount_entry.get())
                if amount <= 0:
                    messagebox.showerror("Error", "Amount must be greater than zero.")
                    return

                data = load_data()
                user_data = data['users'][user_id]
                current_balance = user_data.get("balance", 0)

                user_data["balance"] = current_balance + amount
                save_data(data)
                messagebox.showinfo("Success", f"Deposit successful. New balance: {user_data['balance']}")
                logged_in_user_gui(root, mycanvas, user_id)
            except ValueError:
                messagebox.showerror("Error", "Invalid amount entered.")

        tk.Button(mycanvas, text="Confirm", command=confirm_deposit, width=20, height=2, bg=HEADING_COLOR).place(x=400, y=300, anchor="center")

        # Button to go back to user menu
        back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
        back_button.place(x=400, y=350, anchor="center")

def withdrawal_gui(mycanvas, user_id, root):
            # Clear the mycanvas
            for widget in mycanvas.winfo_children():
                widget.destroy()

            mycanvas.pack(fill="both", expand=True)
            mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
            mycanvas.create_text(400, 100, text="Make Withdrawal", font=("Helvetica", 40), fill=HEADING_COLOR)

            tk.Label(mycanvas, text="Enter amount to withdraw:", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR).place(x=300, y=200, anchor="e")
            amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
            amount_entry.place(x=310, y=200, anchor="w")

            def confirm_withdrawal():
                try:
                    amount = float(amount_entry.get())
                    if amount <= 0:
                        messagebox.showerror("Error", "Amount must be greater than zero.")
                        return

                    data = load_data()
                    user_data = data['users'][user_id]
                    current_balance = user_data.get("balance", 0)

                    if amount > current_balance:
                        messagebox.showerror("Error", "Insufficient funds.")
                        return

                    user_data["balance"] = current_balance - amount
                    save_data(data)
                    messagebox.showinfo("Success", f"Withdrawal successful. New balance: {user_data['balance']}")
                    logged_in_user_gui(root, mycanvas, user_id)
                except ValueError:
                    messagebox.showerror("Error", "Invalid amount entered.")

            tk.Button(mycanvas, text="Confirm", command=confirm_withdrawal, width=20, height=2, bg=HEADING_COLOR).place(x=400, y=300, anchor="center")

            # Button to go back to user menu
            back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
            back_button.place(x=400, y=350, anchor="center")

def show_balance_gui(root, mycanvas, user_id):
    from data_handler import load_data

    # Clear the canvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Your Balance", font=("Helvetica", 40), fill=HEADING_COLOR)

    # Load user data and fetch the balance
    data = load_data()
    if user_id in data["users"]:
        balance = data["users"][user_id]["balance"]
        balance_text = f"Your current balance is: {balance:.2f}SEK"
    else:
        balance_text = "There was a problem retrieving your information"

    mycanvas.create_text(400, 200, text=balance_text, font=("Helvetica", 20), fill=HEADING_COLOR)

    back_button = tk.Button(mycanvas, text="Back", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)  
    back_button_window = mycanvas.create_window(400, 300, anchor="center", window=back_button)


def manage_child_accounts_gui(root, mycanvas, user_id):
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Manage Child Accounts", font=("Helvetica", 30), fill=HEADING_COLOR)

    create_account_button = tk.Button(mycanvas, text="Create Child Account", command=lambda: create_child_account_gui(root, mycanvas, user_id), width=30, height=2, bg=HEADING_COLOR)
    create_account_button_window = mycanvas.create_window(400, 150, anchor="center", window=create_account_button)

    show_balance_button = tk.Button(mycanvas, text="Show Child Balance", command = lambda : show_child_balance_gui(root, mycanvas, user_id), width=30, height=2, bg=HEADING_COLOR)
    show_balance_button_window = mycanvas.create_window(400, 200, anchor="center", window=show_balance_button)

    deposit_money_button = tk.Button(mycanvas, text="Add Money to Child Account", command = lambda : deposit_money_to_child_account_gui(root, mycanvas, user_id), width=30, height=2, bg=HEADING_COLOR)
    deposit_money_button_window = mycanvas.create_window(400, 250, anchor="center", window=deposit_money_button)

    withdraw_money_button = tk.Button(mycanvas, text="Withdraw Money from Child Account",command=lambda: withdraw_form_child_gui(root,mycanvas,user_id), width=30, height=2, bg=HEADING_COLOR)
    withdraw_money_button_window = mycanvas.create_window(400, 300, anchor="center", window=withdraw_money_button)

    back_button = tk.Button(mycanvas, text="Back", width=20, height=2, bg=HEADING_COLOR, command=lambda: logged_in_user_gui(root, mycanvas, user_id))
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def create_child_account_gui(root, mycanvas, user_id):
    from auth import validate_personal_number, generate_account_number
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Create Child Account", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    data = load_data()
    users = data.get("users", {})

    if user_id not in users:
        messagebox.showerror("Error", "Parent account not found!")
        return

    parent_data = users[user_id]

    if "child_accounts" not in parent_data:
        parent_data["child_accounts"] = {}

    # Input fields
    name_label = tk.Label(mycanvas, text="Child's Full Name", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    name_label_window = mycanvas.create_window(300, 100, anchor="e", window=name_label)

    name_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    name_entry_window = mycanvas.create_window(400, 100, anchor="w", window=name_entry)

    personal_number_label = tk.Label(mycanvas, text="Child's Personal Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    personal_number_label_window = mycanvas.create_window(300, 150, anchor="e", window=personal_number_label)

    personal_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    personal_number_entry_window = mycanvas.create_window(400, 150, anchor="w", window=personal_number_entry)

    password_label = tk.Label(mycanvas, text="Child's Password", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=SUBHEADING_COLOR)
    password_label_window = mycanvas.create_window(300, 200, anchor="e", window=password_label)

    password_entry = tk.Entry(mycanvas, font=("Helvetica", 14), show="*")
    password_entry_window = mycanvas.create_window(400, 200, anchor="w", window=password_entry)

    def create_child_account():
        # Get user inputs
        child_name = name_entry.get().strip()
        child_personal_number = personal_number_entry.get().strip()
        child_password = password_entry.get().strip()

        # Validate inputs
        if not child_name or not child_personal_number or not child_password:
            messagebox.showerror("Error", "All fields are required!")
            return

        if not validate_personal_number(child_personal_number):
            messagebox.showerror("Error", "Invalid personal number.")
            return

        # Check if child account already exists
        if child_personal_number in parent_data["child_accounts"]:
            messagebox.showerror("Error", "Child account with this personal number already exists!")
            return

        # Hash the password
        hashed_password = hash_password(child_password)

        # Generate child account number
        childs_account_number = generate_account_number()

        # Create child account
        parent_data["child_accounts"][child_personal_number] = {
            "permissions": {
                "login permission": True,
                "withdraw permission": True,
                "transactions permission": True,
                "deposit permission": True,
            },
            "child account number": childs_account_number,
            "balance": 0,
            "full name": child_name,
            "child personal number": child_personal_number,
            "child's password": hashed_password,  # Save hashed password
            "transaction_history": [],
        }

        save_data(data)
        messagebox.showinfo("Success", f"Child account created successfully! Account Number: {childs_account_number}")
        logged_in_user_gui(root, mycanvas, user_id)

    # Buttons
    submit_button = tk.Button(mycanvas, text="Create Account", command=create_child_account, width=20, height=2, bg=SUBHEADING_COLOR)
    submit_button_window = mycanvas.create_window(400, 300, anchor="center", window=submit_button)

    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: logged_in_user_gui(root, mycanvas, user_id), width=20, height=2, bg=SUBHEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def show_child_balance_gui(root, mycanvas, user_id):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Child Accounts Balance", font=("Helvetica", 40), fill=HEADING_COLOR)

    data = load_data()
    users = data["users"]
    child_accounts = users[user_id].get("child_accounts", {})

    y = 100
    if not child_accounts:
        mycanvas.create_text(400, y, text="No child accounts found.", font=("Helvetica", 14), fill=HEADING_COLOR)
    else:
        y += 50  # Add some space from the title
        for child_id, child_account in child_accounts.items():
            child_name = child_account.get("full name", "Unknown")
            account_info = f"{child_name} ---> Balance: {child_account['balance']} SEK"
            account_label = tk.Label(mycanvas, text=account_info, font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
            mycanvas.create_window(400, y, anchor="center", window=account_label)
            y += 30

    # Button to go back to child menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: manage_child_accounts_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, y + 50, anchor="center", window=back_button)

def withdraw_form_child_gui(root, mycanvas, user_id):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Withdrawal", font=("Helvetica", 40), fill=HEADING_COLOR)

    # Creating the labels and entry boxes account number and amount
    amount_label = tk.Label(mycanvas, text="Amount", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    amount_label_window = mycanvas.create_window(300, 200, anchor="e", window=amount_label)
    amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    amount_entry_window = mycanvas.create_window(400, 200, anchor="w", window=amount_entry)

    account_number_label = tk.Label(mycanvas, text="Account Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    account_number_label_window = mycanvas.create_window(300, 250, anchor="e", window=account_number_label)
    account_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    account_number_entry_window = mycanvas.create_window(400, 250, anchor="w", window=account_number_entry)

    # Handling the logic behind the withdrawal form
    def handle_withdrawal():

        amount = amount_entry.get()
        account_number = account_number_entry.get()

        data = load_data()
        users = data["users"]
        child_account = users[user_id]["child_accounts"]
    
        for child_account in child_account.values():
            if str(child_account["child account number"]) == account_number:
                if not amount:
                    messagebox.showerror("Error", "Amount field cannot be empty.")
                    return
                elif not amount.isdigit():
                    messagebox.showerror("Error", "Amount must be a number.")
                    return
                elif int(amount) < 0:
                    messagebox.showerror("Error", "Amount must be a positive number.")
                    return
                elif not account_number:
                    messagebox.showerror("Error", "Account number field cannot be empty.")
                    return
                elif int(amount) > child_account["balance"]:
                    messagebox.showerror("Error", "Insufficient funds.")
                    return
                else:
                    child_account["balance"] -= int(amount)
                    users[user_id]["balance"] += int(amount)
                    save_data(data)
                    messagebox.showinfo("Success", f"Withdrawal of {amount} made successfully.")   
            else:
                messagebox.showerror("Error", "Account number does not exist.")
    
    # Creating the withdrawal button
    withdrawal_button = tk.Button(mycanvas, text="Withdraw", command=handle_withdrawal, width=20, height=2, bg=HEADING_COLOR)
    withdrawal_button_window = mycanvas.create_window(400, 300, anchor="center", window=withdrawal_button)

   # Button to go back to child menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: manage_child_accounts_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def deposit_money_to_child_account_gui(root, mycanvas, user_id):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Deposit money to Child", font=("Helvetica", 40), fill=HEADING_COLOR)

    # Creating the labels and entry boxes account number and amount
    amount_label = tk.Label(mycanvas, text="Amount", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    amount_label_window = mycanvas.create_window(300, 200, anchor="e", window=amount_label)
    amount_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    amount_entry_window = mycanvas.create_window(400, 200, anchor="w", window=amount_entry)

    account_number_label = tk.Label(mycanvas, text="Account Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    account_number_label_window = mycanvas.create_window(300, 250, anchor="e", window=account_number_label)
    account_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    account_number_entry_window = mycanvas.create_window(400, 250, anchor="w", window=account_number_entry)

    # Handling the logic behind the withdrawal form
    def handle_child_deposit():

        amount = amount_entry.get()
        account_number = account_number_entry.get()

        data = load_data()
        users = data["users"]
        child_account = users[user_id]["child_accounts"]
    
        for child_account in child_account.values():
            if str(child_account["child account number"]) == account_number:
                if not amount:
                    messagebox.showerror("Error", "Amount field cannot be empty.")
                    return
                elif not amount.isdigit():
                    messagebox.showerror("Error", "Amount must be a number.")
                    return
                elif int(amount) < 0:
                    messagebox.showerror("Error", "Amount must be a positive number.")
                    return
                elif not account_number:
                    messagebox.showerror("Error", "Account number field cannot be empty.")
                    return
                else:
                    child_account["balance"] += int(amount)
                    users[user_id]["balance"] -= int(amount)
                    save_data(data)
                    messagebox.showinfo("Success", f"Deposite of {amount}SEK was made successfully.")
                    return 
            else:
                messagebox.showerror("Error", "Account number does not exist.")
    
    # Creating the withdrawal button
    deposit_button = tk.Button(mycanvas, text="Deposit", command = handle_child_deposit, width=20, height=2, bg=HEADING_COLOR)
    deposit_button_window = mycanvas.create_window(400, 300, anchor="center", window = deposit_button)

   # Button to go back to child menu
    back_button = tk.Button(mycanvas, text="Back to User Menu", command=lambda: manage_child_accounts_gui(root, mycanvas, user_id), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def admin_login_gui(root, mycanvas):
    # Clear the mycanvas
    for widget in mycanvas.winfo_children():
        widget.destroy()    

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 100, text="Admin Login", font=("Helvetica", 40), fill=HEADING_COLOR)

    
    # Creating the labels and entry boxes for personal number and password
    personal_number_label = tk.Label(mycanvas, text="Personal Number", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    personal_number_label_window = mycanvas.create_window(300, 200, anchor="e", window=personal_number_label)
    
    personal_number_entry = tk.Entry(mycanvas, font=("Helvetica", 14))
    personal_number_entry_window = mycanvas.create_window(400, 200, anchor="w", window=personal_number_entry)
    
    password_label = tk.Label(mycanvas, text="Password", font=("Helvetica", 14), bg=BACKGROUND_COLOR, fg=HEADING_COLOR)
    password_label_window = mycanvas.create_window(300, 250, anchor="e", window=password_label)
    
    password_entry = tk.Entry(mycanvas, font=("Helvetica", 14), show="*")
    password_entry_window = mycanvas.create_window(400, 250, anchor="w", window=password_entry)
    
    # Handling the logic behind admin login
    def handle_admin_login():
        try:
            admin_id = personal_number_entry.get()
            admin_password = password_entry.get()

            if not admin_id or not admin_password:
                messagebox.showerror("Login Failed", "Personal Number and Password fields cannot be empty.")
                return 
            
            # Load data and use it to check for valid admin
            data = load_data()

            if admin_id in data["admins"]:
                if check_password_admin(admin_id, admin_password):
                    admin_menu_gui(root, mycanvas, admin_id)
                else:
                    messagebox.showerror("Login Failed", "Incorrect password. Please try again.")
            else:
                messagebox.showerror("Login Failed", "Invalid user ID or not registered.")
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred: {e}")

    # Creating the login button
    login_button = tk.Button(mycanvas, text="Login", command=handle_admin_login, width=20, height=2, bg=HEADING_COLOR)
    login_button_window = mycanvas.create_window(400, 300, anchor="center", window=login_button)
    # Button to go back to main menu
    back_button = tk.Button(mycanvas, text="Back to Main Menu", command=lambda: mainmenu_gui(root, mycanvas), width=20, height=2, bg=HEADING_COLOR)
    back_button_window = mycanvas.create_window(400, 350, anchor="center", window=back_button)

def admin_menu_gui(root, mycanvas, admin_id):
    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Admin Menu", font=("Helvetica", 40), fill=HEADING_COLOR)

    def create_styled_button(text, command, y):
        button = tk.Button(mycanvas, text=text, command=command, width=20, height=2, bg=HEADING_COLOR)
        mycanvas.create_window(400, y, anchor="center", window=button)

    create_styled_button("View All Users", lambda: view_all_users_gui(root, mycanvas), 150)
    create_styled_button("View All Transactions", lambda: view_all_transactions_gui(root, mycanvas), 200)
    create_styled_button("Approve Loans", lambda: approve_loans_gui(root, mycanvas), 250)
    create_styled_button("View Unpaid Loans", lambda: view_unpaid_loans_gui(root, mycanvas), 300)
    create_styled_button("Logout", lambda: mainmenu_gui(root, mycanvas), 350)

def view_all_users_gui(root, mycanvas):
    data = load_data()
    users = data.get("users", {})

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="All Users", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    y = 100
    for personal_number, user_info in users.items():
        user_text = f"{user_info['first_name']} {user_info['last_name']} ({personal_number})"
        button = tk.Button(mycanvas, text=user_text, font=("Helvetica", 12), bg=HEADING_COLOR, fg="#000000",
                           command=lambda pn=personal_number: view_user_details_gui(root, mycanvas, pn))
        mycanvas.create_window(400, y, anchor="center", window=button)
        y += 40

    back_button = tk.Button(mycanvas, text="Back", font=("Helvetica", 12, "bold"), bg=HEADING_COLOR, fg="#000000",
                             command=lambda: admin_menu_gui(root, mycanvas, None))
    mycanvas.create_window(400, y + 30, anchor="center", window=back_button)

def view_user_details_gui(root, mycanvas, personal_number):

    data = load_data()
    user_info = data["users"].get(personal_number, {})

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="User Details", font=("Helvetica", 30), fill=HEADING_COLOR)

    details = [
        f"Name: {user_info['first_name']} {user_info['last_name']}",
        f"Balance: {user_info['balance']} SEK",
        f"Card Number: {user_info['card_details'][0]}",
        f"Security Question: {user_info['security_question1']}"
    ]

    y = 100
    for detail in details:
        mycanvas.create_text(400, y, text=detail, font=("Helvetica", 14), fill=HEADING_COLOR)
        y += 30

    back_button = tk.Button(mycanvas, text="Back", command=lambda: view_all_users_gui(root, mycanvas), width=20, height=2, bg=HEADING_COLOR)
    mycanvas.create_window(400, y + 30, anchor="center", window=back_button)

def view_all_transactions_gui(root, mycanvas):
    data = load_data()
    users = data.get("users", {})

    for widget in mycanvas.winfo_children():
        widget.destroy()

    canvas_frame = tk.Frame(mycanvas)
    canvas_frame.pack(fill="both", expand=True)

    transaction_canvas = Canvas(canvas_frame, width=800, height=500, bg=BACKGROUND_COLOR)
    transaction_canvas.pack(side="left", fill="both", expand=True)

    #scrollbar added as there are to view all transactions
    scrollbar = Scrollbar(canvas_frame, orient="vertical", command=transaction_canvas.yview)
    scrollbar.pack(side="right", fill="y")
    transaction_canvas.configure(yscrollcommand=scrollbar.set)

    transaction_frame = tk.Frame(transaction_canvas, bg=BACKGROUND_COLOR)
    transaction_canvas.create_window((0, 0), window=transaction_frame, anchor="nw")

    y = 0
    for personal_number, user_info in users.items():
        transactions = user_info.get("transaction_history", [])
        for transaction in transactions:
            transaction_text = f"User: {user_info['first_name']} {user_info['last_name']} | {transaction['date']} - {transaction['type']} - {transaction['amount']} SEK"
            tk.Label(transaction_frame, text=transaction_text, font=("Helvetica", 12), bg=BACKGROUND_COLOR, fg=HEADING_COLOR).grid(row=y, column=0, sticky="w", pady=5)
            y += 1

    back_button = tk.Button(transaction_frame, text="Back", font=("Helvetica", 12, "bold"), bg=HEADING_COLOR, fg="#000000",
                             command=lambda: admin_menu_gui(root, mycanvas, None))
    back_button.grid(row=y + 1, column=0, pady=10)

    transaction_frame.update_idletasks()
    transaction_canvas.config(scrollregion=transaction_canvas.bbox("all"))


def approve_loans_gui(root, mycanvas):

    data = load_data()
    users = data.get("users", {})

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Approve Loans", font=("Helvetica", 30), fill=HEADING_COLOR)

    y = 100
    for personal_number, user_info in users.items():
        loans = user_info.get("loans", [])
        if loans:
            for loan in loans:
                if loan.get("approved"):
                    continue
                loan_text = (f"{user_info['first_name']} {user_info['last_name']} ({personal_number}):\n"
                             f"{loan['loan_name']} - {loan['amount']} SEK")
                mycanvas.create_text(300, y, text=loan_text, font=("Helvetica", 14), fill=HEADING_COLOR, anchor="w")

                #Fixed overflow of text under approve button
                approve_button = tk.Button(mycanvas, text="Approve", command=lambda l=loan, pn=personal_number: approve_loan_action(l, pn, data), width=10, height=1, bg=HEADING_COLOR)
                mycanvas.create_window(600, y, anchor="w", window=approve_button)
                y += 60

    back_button = tk.Button(mycanvas, text="Back", command=lambda: admin_menu_gui(root, mycanvas, None), width=20, height=2, bg=HEADING_COLOR)
    mycanvas.create_window(400, y + 30, anchor="center", window=back_button)


def approve_loan_action(loan, personal_number, data):

    loan["approved"] = True
    loan_amount = loan["amount"]
    user_info = data["users"][personal_number]
    user_info["balance"] += loan_amount
    save_data(data)
    messagebox.showinfo("Success", f"Loan for {personal_number} has been approved, refresh page to update information")

def view_unpaid_loans_gui(root, mycanvas):
    data = load_data()
    users = data.get("users", {})

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text="Unpaid Loans", font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    y = 100
    for personal_number, user_info in users.items():
        unpaid_loans = [loan for loan in user_info.get("loans", []) if not loan.get("paid", False)]

        if unpaid_loans:
            user_button = tk.Button(mycanvas, text=f"{user_info['first_name']} {user_info['last_name']}",
                                     font=("Helvetica", 12), bg=HEADING_COLOR, fg="#000000",
                                     command=lambda pn=personal_number: view_user_unpaid_loans_gui(root, mycanvas, pn))
            mycanvas.create_window(400, y, anchor="center", window=user_button)
            y += 40

    back_button = tk.Button(mycanvas, text="Back", font=("Helvetica", 12, "bold"), bg=HEADING_COLOR, fg="#000000",
                             command=lambda: admin_menu_gui(root, mycanvas, None))
    mycanvas.create_window(400, y + 30, anchor="center", window=back_button)


def view_user_unpaid_loans_gui(root, mycanvas, personal_number):

    data = load_data()
    user_info = data.get("users", {}).get(personal_number, {})
    unpaid_loans = [loan for loan in user_info.get("loans", []) if not loan.get("paid", False)]

    for widget in mycanvas.winfo_children():
        widget.destroy()

    mycanvas.pack(fill="both", expand=True)
    mycanvas.create_rectangle(0, 0, 800, 500, fill=BACKGROUND_COLOR)
    mycanvas.create_text(400, 50, text=f"Unpaid Loans for {user_info['first_name']} {user_info['last_name']}",
                         font=("Helvetica", 30, "bold"), fill=HEADING_COLOR)

    y = 100
    if unpaid_loans:
        for loan in unpaid_loans:
            loan_text = f"Loan: {loan['loan_name']} - {loan['amount']} SEK"
            mycanvas.create_text(400, y, text=loan_text, font=("Helvetica", 12), fill=HEADING_COLOR)
            y += 20
    else:
        mycanvas.create_text(400, y, text="No unpaid loans.", font=("Helvetica", 12), fill=HEADING_COLOR)

    back_button = tk.Button(mycanvas, text="Back", font=("Helvetica", 12, "bold"), bg=HEADING_COLOR, fg="#000000",
                             command=lambda: view_unpaid_loans_gui(root, mycanvas))
    mycanvas.create_window(400, y + 30, anchor="center", window=back_button)
