from data_handler import load_data, save_data
from utils import clear_console
from menus import handle_main_menu
from datetime import datetime
import time



def admin_menu(data):

    choice = None
    clear_console()
    message = """
    ╔══════════════════════════════╗
    ║         Admin Menu           ║
    ║                              ║
    ║ → [1] View All Users         ║
    ║ → [2] View All Transactions  ║
    ║ → [3] Approve Loans          ║
    ║ → [4] View All Unpaid Loans  ║
    ║ → [5] Logout                 ║
    ╚══════════════════════════════╝
    """
    while choice != "5":  
        clear_console()
        print(message)
        
        choice = input("Enter your choice: ")

        if choice == "1":
            clear_console()
            time.sleep(2)
            display_user_data(data)

        elif choice == "2": 
            clear_console()
            time.sleep(2)
            view_admin_transaction_history()
        
        elif choice == "3":
            clear_console()
            approve_user_loans(data)
        
        elif choice == "4":
            clear_console()
            view_admin_unpaid_loans(data)

        elif choice == "5":
            print("Logging out")
            time.sleep(2)
            clear_console()
            handle_main_menu()
        else:
            print("Invalid option. Please try again.")
         
         
def display_user_data(data):
    users = list(data['users'].items())
    clear_console()
    display_users(data)

    admin_choice = None
    while admin_choice != len(users) + 1: 
        try:
            admin_choice = int(input("\nSelect a user by their option number: "))

            if admin_choice == len(users) + 1:  
                print("Returning to the main menu.")
                return
            user_data = get_user_data(data, admin_choice)
            if user_data:
                clear_console()
                print("\n=== User Details ===")
                for key, value in user_data.items():
                    if key == "transaction_history" and value:
                        print(f"\n{key.capitalize()}:")
                        for index, transaction in enumerate(value, start=1):
                            print(f"  Transaction {index}:")
                            for t_key, t_value in transaction.items():
                                print(f"    {t_key.capitalize()}: {t_value}")
                    else:
                        print(f"{key.capitalize()}: {value}")
                print("\nEnter 0 to return to the Users List.")

                return_choice = input("Enter your choice: ")
                if return_choice == "0":
                    clear_console()
                    display_users(data)
                else:
                    print("Invalid option. Please try again.")
                
            else:
                print("Invalid option. Please try again.")
        except ValueError:
            print("Invalid input! Please enter a valid number.")

def view_admin_transaction_history():
    data = load_data()
    print("All Users' Transaction Histories:")
    
    for personal_number, user_data in data["users"].items():

        history = user_data.get("transaction_history", [])
        print(f"\nTransaction History for {user_data['first_name']} {user_data['last_name']} ({personal_number}):")
        
        if not history:
            print("No transactions available.")
        else:
            counter = 1 
            for transaction in history:
                print(f"{counter}. Type: {transaction['type'].capitalize()}")
                print(f"   Amount: {transaction['amount']:.2f} SEK")
                print(f"   Date: {transaction['date']}")
                print(f"   Balance after transaction: {transaction['new_balance']:.2f} SEK")
                print("-" * 40)
                
                counter += 1 
    
    
    input("Press Enter to return to the previous menu.")
    clear_console()

def get_user_data(data, option):
    users = list(data['users'].items())
    if 1 <= option <= len(users):
        personal_number, user_info = users[option - 1]
        return {**user_info, 'personal_number': personal_number}
    else:
        return None 
    
def display_users(data):
   
   users = list(data["users"].items())
   index = 0
   while index < len(users):
       personal_number, user_info = users[index]
       print(f"{index + 1}. {user_info['first_name']} {user_info['last_name']} ({personal_number})")
       index += 1
   print(f"{index + 1}. Exit")

def approve_user_loans(data):
    personal_number = input("Enter the personal number of the customer: ")
    user = data["users"].get(personal_number)
    
    if not user: 
        print(f"No user with personal number {personal_number} found.")
        input("Press Enter to return to the admin menu...")
        clear_console()
        admin_menu(data)
        return

    if "loans" not in user or not user["loans"]:  
        print("No loans found for this user.")
        input("Press Enter to return to the admin menu...")
        clear_console()
        admin_menu(data)
        return
    

    counter = 1
    for loan in user["loans"]:
        print(f"{counter}. {loan['loan name']}")
        counter += 1

    try:
        options = int(input("Select a loan to approve: "))
        if 0 >= options > 2:
            print("invalid option. Please enter a valid option.")
            time.sleep(2)
            clear_console()
            admin_menu(data)
    except ValueError:
        print("Invalid input. Please enter a number.")
        time.sleep(2)
        clear_console()
        admin_menu(data)
        return

    loan = user["loans"][options - 1]

    print(f"\nCustomer Name: {user['first_name']} {user['last_name']}")
    print(f"Balance: SEK{user['balance']:,.2f}")

        
    print("\nLoan Details:")
    print(f"  - Loan Name: {loan['loan name']}")
    print(f"  - Loan Amount: ${loan['amount']:,.2f}")
    print(f"  - Description: {loan['description']}")
    print(f"  - Approved: {'Yes' if loan['approved'] else 'No'}")

    choice = input("\nWould you like to approve this loan? Type 'Yes' or 'No': ").lower()
    if choice == "yes":
        loan["approved"] = True
        print("\nLoan Approved.")
    elif choice == "no":
        loan["approved"] = False
        print("\nLoan Remains Rejected.")
    else:
        print("\nInvalid choice. Loan status unchanged.")

    save_data(data)
    print("Loan Process Completed.")
    time.sleep(1)
    input("Press Enter to return to the admin menu...")
    clear_console()
    admin_menu(data)

def calculate_due_amount(data):  #more loan function nality can be done later by implementation by simple 'for loop' print.
    """Updates the amount due for a  user when the admins check the user's account.
    So, to update money due you need to check all users. Automation will be done next sprint 16 December 2024"""
    
    personal_number = input("Enter the personal number of the customer: ")
    user = data["users"].get(personal_number)

    if not user:
        print(f"No user with personal number {personal_number} found.")
        value = user["loans"][0]["amount"]
        calculate_due_amount(data)

    if "loans" not in user or not user["loans"]:
        print("No loans found for this user.")
        calculate_due_amount(data)

    start_date = datetime.strptime(user["loans"][0]["Start_Date"], "%Y-%m-%d")
    today = datetime.now()
    days_passed = (today - start_date).days

    if days_passed > 0:
            # Compound interest formula: A = P * (1 + r)^t
            rate = 0.012  # 1.2% daily interest
            compounded_amount = value * ((1 + rate) ** days_passed)

            # Update loan details
            value = round(compounded_amount, 2)
            user["loans"][0]["Start_Date"] = today.strftime("%Y-%m-%d")

            print(f"Updated Amount (after {days_passed} days of compounding): SEK{value}")
    else:
        print("No interest accrued since the last update.")
    
    time.sleep(2)
    clear_console()
    admin_menu(data)

def view_admin_unpaid_loans(data):
    print("All Users'  unpaid loans:")
    
    for personal_number, user_data in data["users"].items():

        history = user_data.get("loans", [])
        print(f"\nUnpaid loans for {user_data['first_name']} {user_data['last_name']} ({personal_number}):")
        
        if not history:
            print("No unpaid loans.")
        else:
            counter = 1 
            for loan in history:
                print(counter, ". ", loan )

                
                counter += 1 
    
    
    input("Press Enter to return to the previous menu.")
    clear_console()