
from utils import clear_console
from tqdm import tqdm
import time
from data_handler import load_data
from colorama import Fore, Style

def display_title():
    clear_console()
    title = f"""
                   {Fore.GREEN}███████╗██╗███████╗    ██████╗  █████╗ ███╗   ██╗██╗  ██╗
                   ██╔════╝██║██╔════╝    ██╔══██╗██╔══██╗████╗  ██║██║ ██╔╝
                   ███████╗██║█████╗      ██████╔╝███████║██╔██╗ ██║█████╔╝ 
                   ╚════██║██║██╔══╝      ██╔══██╗██╔══██║██║╚██╗██║██╔═██╗ 
                   ███████║██║██║         ██████╔╝██║  ██║██║ ╚████║██║  ██╗
                   ╚══════╝╚═╝╚═╝         ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝
                   {Style.RESET_ALL}
    """                                                                                                                                                 
    
    print(title)
    desc = "loading"
    progress_bar = tqdm(range(100), desc=desc, ncols=90, bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}%")
    for i in range(10):
        progress_bar.update(n=10)
        time.sleep(0.5)
    progress_bar.close()
    time.sleep(1)
    clear_console()

def display_main_menu():
    
    user_selector = f"""{Fore.YELLOW}
    ╔═════════════════════════╗
    ║     USERS SELECTOR      ║
    ║                         ║
    ║ → [1] User              ║
    ║ → [2] Administrator     ║
    ║ → [3] Exit              ║
    ╚═════════════════════════╝
        {Style.RESET_ALL}"""
    print(user_selector)
    return input("\nSelect the type of user: ").strip()

def handle_main_menu():
    from auth import admin_login
    option = None
    while option != "3":
        clear_console()
        option = display_main_menu()

        if option == "1":
            handle_user_menu()
        elif option == "2":
            clear_console()
            admin_login()
        elif option == "3":
            clear_console()
            print("Exiting the system. Goodbye!")

        else:
            clear_console()
            print("Invalid option. Please try again.")
            time.sleep(2)
            
def display_user_menu():
    user_menu = f"""{Fore.MAGENTA}
    ╔═════════════════════════╗
    ║        User Menu        ║
    ║                         ║
    ║ → [1] Login             ║
    ║ → [2] Child             ║
    ║ → [3] Forgot password?  ║
    ║ → [4] Register          ║
    ║ → [5] Go Back           ║
    ╚═════════════════════════╝
        {Style.RESET_ALL}
        """
    print(user_menu)
    return input("\nSelect an option: ").strip()

def handle_user_menu():
    from auth import reset_password, user_registration, user_login
    from bank_operations import child_login
    option = None
    while option != "5":
        clear_console()
        option = display_user_menu()

        if option == "1":
            clear_console()
            user_login()

        if option == "2":
            clear_console()
            child_login()
        
        elif option == "3":
            clear_console()
            reset_password()
        
        elif option == "4":
            clear_console()
            user_registration()

        elif option == "5":
            return

        else:
            clear_console()
            print("Invalid option. Please try again.")
            time.sleep(2)

def extras_menu(user_id):
    from bank_operations import create_personal_loan, pay_loan, get_stock_data, show_stock_data, create_mortgage_loan, update_loan_interest_daily, force_execute_in_order
    from data_handler import get_currencies
    from bank_operations import pay_loan
    from utils import generate_qr_code

    data = load_data()


    message = f"""{Fore.LIGHTGREEN_EX}
    ╔═════════════════════════╗
    ║       EXTRA MENU        ║
    ║                         ║
    ║ → [1] Personal loan     ║
    ║ → [2] Mortgage loan     ║
    ║ → [3] Change currency   ║
    ║ → [4] View loans        ║
    ║ → [5] Pay Loans         ║
    ║ → [6] Feedback survey   ║
    ║ → [7] View recent stock ║               
    ║ → [8] Go back           ║
    ╚═════════════════════════╝
    {Style.RESET_ALL}
    """
    option = ""
    while option != "8":
        clear_console()
        print(message)
        option = input("\nEnter your option: ")
    
        match option:
            case "1":
                clear_console()
                time.sleep(2)
                create_personal_loan(user_id, data)

            case "2":
                clear_console()
                create_mortgage_loan(user_id, data)
                time.sleep(2)
                
            case "3":
                clear_console()
                rates = get_currencies()
                sek_to_eur = 1 / rates["SEK"]  

                user_money = input("Enter the amount of money you want to convert (in SEK): ")
                user_currency = input("Enter the currency (abbreviation) you want to convert to: ").upper()

                if user_currency in rates:
                    money_in_eur = float(user_money) * sek_to_eur
                    converted_money = money_in_eur * rates[user_currency]

                    print(f"\n{user_money} SEK is equal to {converted_money:.2f} {user_currency}.")
                    time.sleep(1)
                    input("Press Enter to continue...")
                    return
                else:
                    clear_console()
                    print("Curreny does not exists. Please try again.")
                    time.sleep(2)
            
            case "4":
                clear_console()
                print("view loans feature is under construction.")
                time.sleep(2)
            
            case "5":
                clear_console()
                force_execute_in_order(
                    lambda: update_loan_interest_daily(user_id, data),
                    lambda: pay_loan(user_id, data)
)
                
            case "6":
                clear_console()
                generate_qr_code()
                input("\nPress Enter to continue...")
            case "7":
                get_stock_data()
                show_stock_data()
            case "8":
                return
            case _:
                clear_console()
                print("Invalid option. Please try again.")
                time.sleep(2)

def childs_menu(child_id, name):
    from bank_operations import child_withdraw_money, family_transfer_money
    from bank_operations import show_childs_balance, transfer_money, withdraw_money
    from auth import user_login
    option = "tyra"
    while option != "5":
    

        box_width = 35
        max_name_length = box_width - 14 
    
        if len(name) > max_name_length:
            name = name[:max_name_length - 3] + "..."  
        else:
            name = name.ljust(max_name_length)  

        print(f"""{Fore.GREEN}
        ╔{'═' * box_width}╗
        ║ Welcome {name}     ║
        ╠{'═' * box_width}╣
        ║ {' ' * (box_width - 2)} ║
        ║ → [1] Show Balance{' ' * (box_width - 21)}  ║
        ║ → [2] Make Family Transaction{' ' * (box_width - 31)} ║
        ║ → [3] Show Transaction History{' ' * (box_width - 32)} ║
        ║ → [4] Make Withdrawal{' ' * (box_width - 23)} ║
        ║ → [5] Log out{' ' * (box_width - 15)} ║
        ╚{'═' * box_width}╝
        {Style.RESET_ALL}
        """)
        option = input("\nSelect an option: ").strip()
    
        if option == "1":
            clear_console()
            show_childs_balance(child_id)
        elif option == "2":
            clear_console()
            family_transfer_money(child_id, name)

        elif option == "3":
            clear_console()
            print("Show Transaction History feature is under construction.")
        elif option == "4":
            clear_console()
            child_withdraw_money(child_id, name)
        elif option == "5":
            print("Logging out...")
            time.sleep(2)
        else:
            clear_console()
            print("Invalid option. Please try again.")
        time.sleep(2)
        
def child_account_menu(user_id):
    from bank_operations import create_child_account, manage_child_account
    menu = f"""{Fore.CYAN}
    ╔════════════════════════════╗
    ║     CHILD ACCOUNT MENU     ║
    ║                            ║
    ║ → [1] Create child account ║
    ║ → [2] Manage child account ║
    ║ → [3] Exit                 ║
    ╚════════════════════════════╝
        {Style.RESET_ALL}"""
    print(menu)
    menu = int(input("Enter: "))
    if menu == 1:
        create_child_account(user_id)
    elif menu == 2:
        manage_child_account(user_id)
    elif menu == 3:
        return
    else:
        print("Error: Invalid input. Please chose from the given options.")
        child_account_menu(user_id)
        
def user_menu(user_id, name):
    from bank_operations import show_balance, transfer_money, view_user_transaction_history, deposit_money, withdraw_money, create_savings_account, show_bank_card

    data = load_data()
    option = None
    image_source = "./cards/bluecard.png"
    while option != "10":
        clear_console()

        box_width = 35
        max_name_length = box_width - 14 
    
        if len(name) > max_name_length:
            name = name[:max_name_length - 3] + "..."  
        else:
            name = name.ljust(max_name_length)  

        print(f"""{Fore.LIGHTMAGENTA_EX}
        ╔{'═' * box_width}╗
        ║ Welcome {name}     ║
        ╠{'═' * box_width}╣
        ║ {' ' * (box_width - 2)} ║
        ║ → [1] Show Balance{' ' * (box_width - 21)}  ║
        ║ → [2] Make Transaction{' ' * (box_width - 24)} ║
        ║ → [3] Show Transaction History{' ' * (box_width - 32)} ║
        ║ → [4] Child's Account{' ' * (box_width - 25)}   ║
        ║ → [5] Make Deposit{' ' * (box_width - 20)} ║
        ║ → [6] Make Withdrawal{' ' * (box_width - 23)} ║
        ║ → [7] Create Savings account{' ' * (box_width - 30)} ║
        ║ → [8] Show card{' ' * (box_width - 17)} ║
        ║ → [9] Extras   {' ' * (box_width - 17)} ║
        ║ → [10] Log out{' ' * (box_width - 15)}║
        ╚{'═' * box_width}╝
        {Style.RESET_ALL}
        """)

        option = input("\nSelect an option: ").strip()
    
        if option == "1":
            clear_console()
            show_balance(user_id)
        elif option == "2":
            clear_console()
            transfer_money(user_id, data)
        elif option == "3":
            clear_console()
            view_user_transaction_history(user_id)
        elif option == "4":
            clear_console()
            child_account_menu(user_id)
        elif option == "5":
            clear_console()
            deposit_money(user_id)
        elif option == "6":
            clear_console()
            withdraw_money(user_id)
        elif option == "7":
            clear_console()
            create_savings_account(user_id, 0.01)
        elif option == "8":
            clear_console()
            show_bank_card(image_source, user_id)
        elif option == "9":
            clear_console()
            extras_menu(user_id) 
        elif option == "10":
            clear_console()
            print("Logging out...")
            time.sleep(2)
            break
        else:
            clear_console()
            print("Invalid option. Please try again.")
            time.sleep(2)



