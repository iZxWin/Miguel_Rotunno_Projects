import os
import json
import random
import requests


DATA_FILE = os.path.join('.', 'users.json')

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    return {"users": {}, "admins": {}} # returns an empty json in case the users json was not found

def save_data(data):
    with open(DATA_FILE, "w") as file:
        json.dump(data, file, indent=4)

def generate_account_number():
    account_number = random.randint(10**9, 10**10-1)
    return account_number

def get_currencies():
    url = "http://api.exchangeratesapi.io/v1/latest?access_key=281b2e2b33bb38df622de91a85502592&base=EUR"
    resp = requests.get(url)
    data = resp.json()
    rates = data["rates"]
    return rates